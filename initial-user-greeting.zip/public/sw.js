/* LearnOrbit service worker
 * Network-first for everything on our own origin, so a new deploy is picked up immediately;
 * the cache is only a fallback when the visitor is offline.
 * Third-party requests (Wikipedia, YouTube thumbnails, APIs…) are never touched.
 */
const CACHE = "learnorbit-shell-v1";

self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith("/sw.js") || url.searchParams.has("_v")) return;

  event.respondWith(
    (async () => {
      try {
        const res = await fetch(req);
        if (res && res.ok && res.type === "basic") {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => undefined);
        }
        return res;
      } catch (err) {
        const hit = (await caches.match(req)) || (req.mode === "navigate" ? await caches.match(new URL("./", self.location).href) : undefined);
        if (hit) return hit;
        if (req.mode === "navigate") {
          const any = await caches.match(self.registration.scope);
          if (any) return any;
        }
        return Response.error();
      }
    })()
  );
});
