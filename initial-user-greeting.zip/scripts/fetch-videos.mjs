#!/usr/bin/env node
/**
 * Refreshes src/data/videos.json — the "verified" YouTube catalog.
 *
 *   node scripts/fetch-videos.mjs            -> all topics
 *   node scripts/fetch-videos.mjs Python Yoga -> only those topics (merged into the file)
 *
 * For every topic it searches YouTube, filters out shorts / live streams / junk,
 * then confirms each video with YouTube's oEmbed endpoint (a 200 response means the
 * video exists AND can be embedded). Only passing videos are saved, so the website
 * never links to a dead or blocked video.
 *
 * Runs weekly via .github/workflows/refresh-content.yml so the catalog updates itself.
 */
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const topicsPath = path.join(root, "src/data/topics.json");
const outPath = path.join(root, "src/data/videos.json");

const PER_TOPIC = 5;
const CONCURRENCY = Number(process.env.CONCURRENCY || 2);
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
const BLOCKED =
  /\b(crack(ed)?|keygen|warez|nulled|pirat(e|ed)|torrent|serial key|license key|activator|free download full)\b/i;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function parseDuration(text = "") {
  const parts = text.split(":").map(Number);
  if (parts.some(Number.isNaN)) return 0;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}
function parseViews(text = "") {
  const n = Number((text.match(/[\d,]+/) || ["0"])[0].replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}
function compactViews(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, "") + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1e3) return Math.round(n / 1e3) + "K";
  return String(n);
}

async function searchYouTube(query) {
  const url = "https://www.youtube.com/results?search_query=" + encodeURIComponent(query) + "&hl=en&gl=US";
  const res = await fetch(url, {
    headers: { "user-agent": UA, "accept-language": "en-US,en;q=0.9", cookie: "CONSENT=YES+1; SOCS=CAI" },
  });
  if (!res.ok) throw new Error("YouTube search HTTP " + res.status);
  const html = await res.text();
  const marker = "var ytInitialData = ";
  const start = html.indexOf(marker);
  if (start < 0) throw new Error("ytInitialData not found");
  const end = html.indexOf(";</script>", start);
  const data = JSON.parse(html.slice(start + marker.length, end));
  const sections =
    data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];
  const out = [];
  for (const s of sections) {
    for (const item of s?.itemSectionRenderer?.contents || []) {
      const v = item.videoRenderer;
      if (!v?.videoId) continue;
      const live = (v.badges || []).some((b) => /LIVE/.test(b?.metadataBadgeRenderer?.style || ""));
      const lengthText = v.lengthText?.simpleText;
      if (live || !lengthText) continue;
      out.push({
        id: v.videoId,
        title: (v.title?.runs || []).map((r) => r.text).join(""),
        channel: v.ownerText?.runs?.[0]?.text || "YouTube",
        duration: lengthText,
        seconds: parseDuration(lengthText),
        viewsNum: parseViews(v.viewCountText?.simpleText),
        published: v.publishedTimeText?.simpleText || "",
      });
    }
  }
  return out;
}

async function isEmbeddable(id) {
  try {
    const res = await fetch(
      "https://www.youtube.com/oembed?format=json&url=" + encodeURIComponent("https://www.youtube.com/watch?v=" + id),
      { headers: { "user-agent": UA } }
    );
    return res.status === 200;
  } catch {
    return false;
  }
}

async function buildTopic(topic) {
  const queries = [topic.yt || `learn ${topic.name} for beginners`, `${topic.name} tutorial`];
  const picked = [];
  const seen = new Set();
  const perChannel = new Map();

  for (const q of queries) {
    if (picked.length >= PER_TOPIC) break;
    let results = [];
    for (let attempt = 1; attempt <= 4; attempt++) {
      try {
        results = await searchYouTube(q);
        break;
      } catch (e) {
        console.warn(`  ! ${topic.name} (try ${attempt}): ${e.message}`);
        await sleep(2500 * attempt); // back off when YouTube throttles us
      }
    }
    const candidates = results.filter(
      (v) =>
        v.seconds >= 360 &&
        v.seconds <= 10 * 3600 &&
        v.viewsNum >= 20000 &&
        !BLOCKED.test(v.title) &&
        !seen.has(v.id)
    );
    for (const v of candidates) {
      if (picked.length >= PER_TOPIC) break;
      if ((perChannel.get(v.channel) || 0) >= 2) continue;
      seen.add(v.id);
      if (!(await isEmbeddable(v.id))) continue;
      perChannel.set(v.channel, (perChannel.get(v.channel) || 0) + 1);
      picked.push({
        id: v.id,
        title: v.title,
        channel: v.channel,
        duration: v.duration,
        views: compactViews(v.viewsNum),
        published: v.published,
      });
    }
    await sleep(250);
  }
  return picked;
}

async function main() {
  const { topics } = JSON.parse(await readFile(topicsPath, "utf8"));
  const args = process.argv.slice(2);
  const onlyMissing = args.includes("--missing");
  const only = args.filter((a) => !a.startsWith("--")).map((s) => s.toLowerCase());

  let existing = { generatedAt: null, topics: {} };
  try {
    existing = JSON.parse(await readFile(outPath, "utf8"));
  } catch {
    /* first run */
  }

  let todo = only.length ? topics.filter((t) => only.includes(t.name.toLowerCase())) : topics;
  if (onlyMissing) todo = todo.filter((t) => !(existing.topics[t.name] || []).length);

  const result = { ...existing.topics };
  let index = 0;
  let done = 0;
  async function worker() {
    while (index < todo.length) {
      const topic = todo[index++];
      const vids = await buildTopic(topic);
      // never replace a good list with an empty one (network hiccup)
      if (vids.length) result[topic.name] = vids;
      done++;
      console.log(`[${done}/${todo.length}] ${topic.name}: ${vids.length} verified videos`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));

  const ordered = {};
  for (const t of topics) if (result[t.name]) ordered[t.name] = result[t.name];
  await mkdir(path.dirname(outPath), { recursive: true });
  await writeFile(outPath, JSON.stringify({ generatedAt: new Date().toISOString(), topics: ordered }, null, 1) + "\n");
  const total = Object.values(ordered).reduce((n, a) => n + a.length, 0);
  console.log(`\nSaved ${total} verified videos for ${Object.keys(ordered).length} topics -> src/data/videos.json`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
