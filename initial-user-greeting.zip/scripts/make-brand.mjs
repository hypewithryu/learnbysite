#!/usr/bin/env node
/**
 * Generates the brand images from src/site.config.json:
 *   public/favicon.svg, icon-192.png, icon-512.png, apple-touch-icon.png, og-image.png (1200x630 social card)
 *
 * Needs the (dev-only) "sharp" package:   npm i -D sharp   then   node scripts/make-brand.mjs
 * Edit the name/tagline in src/site.config.json and re-run to refresh every image.
 */
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const cfg = JSON.parse(await readFile(path.join(root, "src/site.config.json"), "utf8"));
const pub = path.join(root, "public");
await mkdir(pub, { recursive: true });

const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const logo = (id = "g") => `
  <defs>
    <linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#8b6cff"/><stop offset="0.55" stop-color="#22d3ee"/><stop offset="1" stop-color="#f472b6"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="16" fill="#0b0b1a"/>
  <circle cx="32" cy="32" r="12" fill="url(#${id})"/>
  <ellipse cx="32" cy="32" rx="25" ry="9" fill="none" stroke="url(#${id})" stroke-width="3" transform="rotate(-24 32 32)"/>
  <circle cx="53" cy="23" r="4" fill="#fff"/>`;

const favicon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">${logo()}</svg>\n`;
await writeFile(path.join(pub, "favicon.svg"), favicon);

const name = esc(cfg.name);
const tagline = esc(cfg.tagline);
const og = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#070711"/><stop offset="1" stop-color="#17113a"/></linearGradient>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b6cff"/><stop offset="0.55" stop-color="#22d3ee"/><stop offset="1" stop-color="#f472b6"/></linearGradient>
    <radialGradient id="orb" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#f9a8d4"/><stop offset="0.45" stop-color="#7c5cff"/><stop offset="1" stop-color="#22d3ee"/></radialGradient>
    <radialGradient id="halo" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8b6cff" stop-opacity="0.55"/><stop offset="1" stop-color="#8b6cff" stop-opacity="0"/></radialGradient>
    <filter id="blur"><feGaussianBlur stdDeviation="30"/></filter>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <g stroke="#ffffff" stroke-opacity="0.05">${Array.from({ length: 22 }, (_, i) => `<path d="M${i * 56} 0V630"/>`).join("")}${Array.from({ length: 12 }, (_, i) => `<path d="M0 ${i * 56}H1200"/>`).join("")}</g>
  <circle cx="990" cy="315" r="300" fill="url(#halo)"/>
  <g transform="translate(990 315) scale(0.78)">
    <ellipse rx="270" ry="86" fill="none" stroke="url(#g)" stroke-width="3" opacity="0.7" transform="rotate(-24)"/>
    <ellipse rx="215" ry="215" fill="none" stroke="#fff" stroke-opacity="0.08" stroke-width="2"/>
    <circle r="130" fill="url(#orb)"/>
    <circle cx="-42" cy="-48" r="42" fill="#fff" opacity="0.18" filter="url(#blur)"/>
    <circle cx="246" cy="-112" r="22" fill="#fb923c"/>
    <circle cx="-120" cy="215" r="17" fill="#34d399"/>
    <circle cx="150" cy="190" r="14" fill="#f472b6"/>
    <circle cx="-120" cy="-190" r="12" fill="#22d3ee"/>
  </g>
  <g transform="translate(80 150) scale(1.9)">${logo("lg")}</g>
  <text x="80" y="340" font-family="Inter, 'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif" font-size="92" font-weight="800" fill="#ffffff">${name}</text>
  <text x="82" y="408" font-family="Inter, 'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif" font-size="38" font-weight="600" fill="url(#g)">${tagline}</text>
  <text x="82" y="470" font-family="Inter, 'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif" font-size="29" fill="#a9aac8">Free videos · guides · books · tips · learning plans</text>
  <g font-family="Inter, 'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif" font-size="24" font-weight="600" fill="#fff">
    <rect x="80" y="515" width="190" height="52" rx="26" fill="#ffffff" fill-opacity="0.09" stroke="#ffffff" stroke-opacity="0.18"/><text x="175" y="549" text-anchor="middle">100% free</text>
    <rect x="286" y="515" width="220" height="52" rx="26" fill="#ffffff" fill-opacity="0.09" stroke="#ffffff" stroke-opacity="0.18"/><text x="396" y="549" text-anchor="middle">Always fresh</text>
    <rect x="522" y="515" width="250" height="52" rx="26" fill="#ffffff" fill-opacity="0.09" stroke="#ffffff" stroke-opacity="0.18"/><text x="647" y="549" text-anchor="middle">No broken links</text>
  </g>
</svg>`;

let sharp;
try {
  sharp = (await import("sharp")).default;
} catch {
  console.log("favicon.svg written. Install sharp (npm i -D sharp) to also generate the PNG images.");
  process.exit(0);
}

const png = (svg, size, file, opts = {}) =>
  sharp(Buffer.from(svg), { density: 300 })
    .resize(size.w, size.h)
    .png()
    .toFile(path.join(pub, file))
    .then(() => console.log("wrote public/" + file, opts.note || ""));

await png(favicon, { w: 192, h: 192 }, "icon-192.png");
await png(favicon, { w: 512, h: 512 }, "icon-512.png");
await png(favicon, { w: 180, h: 180 }, "apple-touch-icon.png");
await png(og, { w: 1200, h: 630 }, "og-image.png");
