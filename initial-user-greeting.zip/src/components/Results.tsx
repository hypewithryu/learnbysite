import { useEffect, useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import { getArticles, getBooks, getCourses, getLiveVideos, getWiki } from "@/lib/api";
import { cacheAge } from "@/lib/cache";
import { absUrl, SITE } from "@/lib/config";
import { PLATFORMS } from "@/lib/links";
import { Link, searchRoute } from "@/lib/router";
import { hasPiracyIntent, stripPiracyWords } from "@/lib/safety";
import { useSEO } from "@/lib/seo";
import { addRecent } from "@/lib/store";
import { cleanQuery, timeAgo, titleCase, truncate, ytWatch } from "@/lib/text";
import { copyText, toast } from "@/lib/toast";
import { categoryFor, curatedVideos, matchTopic, relatedTopics } from "@/lib/topics";
import type { Overview, Resource, Tab, Video } from "@/lib/types";
import { useSource } from "@/lib/useSource";
import { LinkGuardCard } from "./Home";
import { EmptyState } from "./Cards";
import { ExternalIcon, RefreshIcon, ShareIcon, ShieldIcon } from "./Icons";
import { LinksBlock, MistakesBlock, PlanBlock, ResourceGrid, Roadmap, Section, TipsBlock, VideosBlock, type RoadStep } from "./Blocks";
import { Pill, Reveal, SafeImage } from "./Ui";
import { VideoModal } from "./VideoModal";

const TABS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: "all", label: "Overview", icon: "✨" },
  { id: "videos", label: "Videos", icon: "▶️" },
  { id: "read", label: "Read", icon: "📰" },
  { id: "learn", label: "Courses & books", icon: "🎓" },
  { id: "tips", label: "Tips & plan", icon: "💡" },
  { id: "links", label: "Direct links", icon: "🔗" },
];

const platform = (id: string, q: string) => PLATFORMS.find((p) => p.id === id)!.url(q);

function OverviewCard({ overview, loading, name, q }: { overview?: Overview | null; loading: boolean; name: string; q: string }) {
  if (loading && !overview) return <div className="skeleton h-48 rounded-3xl" aria-hidden="true" />;
  if (!overview) {
    return (
      <EmptyState icon="📚" title={`No encyclopedia entry found for “${name}”`}>
        That's OK — explore the videos, courses and direct links below, or{" "}
        <a className="font-semibold text-brand hover:underline" href={platform("wikipedia", q)} target="_blank" rel="noopener noreferrer">
          search Wikipedia directly
        </a>
        .
      </EmptyState>
    );
  }
  return (
    <article className="card flex flex-col overflow-hidden rounded-3xl sm:flex-row">
      {overview.thumb && (
        <div className="relative h-48 shrink-0 bg-surface2 sm:h-auto sm:w-60">
          <SafeImage src={overview.thumb} alt={overview.title} className="absolute inset-0 h-full w-full object-cover" fallback={<span />} />
        </div>
      )}
      <div className="p-5 sm:p-6">
        <Pill tone="brand">🌐 Quick overview · Wikipedia</Pill>
        <h2 className="font-display mt-3 text-xl font-bold sm:text-2xl">What is {overview.title.replace(/\s*\(.*?\)\s*/g, " ").trim()}?</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted sm:text-base">{overview.extract}</p>
        <a href={overview.url} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand hover:underline">
          Read the full article <ExternalIcon size={14} />
        </a>
      </div>
    </article>
  );
}

export default function Results({ q: rawQ, tab }: { q: string; tab: Tab }) {
  const piracy = hasPiracyIntent(rawQ);
  const q = piracy ? stripPiracyWords(rawQ) : rawQ;
  const key = q.toLowerCase();

  const match = useMemo(() => matchTopic(q), [q]);
  const topic = match?.topic;
  const cat = useMemo(() => categoryFor(q) ?? undefined, [q]);
  const name = match?.strength === "exact" ? match.topic.name : titleCase(cleanQuery(q));

  const [nonce, setNonce] = useState(0);
  const [stamp, setStamp] = useState(() => cacheAge(`wiki:${cleanQuery(q).toLowerCase()}`) ?? Date.now());
  const [, setTick] = useState(0);
  const [playing, setPlaying] = useState<Video | null>(null);
  const [bad, setBad] = useState<Set<string>>(new Set());

  const wikiHint = match?.strength === "exact" ? match.topic.wiki : undefined;
  const wiki = useSource(`wiki:${key}`, (f) => getWiki(q, f, wikiHint), nonce);
  const live = useSource(`yt:${key}`, (f) => getLiveVideos(q, f), nonce);
  const devto = useSource(`dev:${key}`, (f) => getArticles(q, topic?.tag, f), nonce);
  const courses = useSource(`cr:${key}`, (f) => getCourses(q, f), nonce);
  const books = useSource(`bk:${key}`, (f) => getBooks(q, f), nonce);

  const loading = [wiki, live, devto, courses, books].some((s) => s.status === "loading");

  useEffect(() => {
    if (!piracy || q) addRecent(q || rawQ);
    setBad(new Set());
    setPlaying(null);
  }, [key, piracy, q, rawQ]);

  // "updated x min ago" label + auto-refresh when you come back to a stale tab
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 60_000);
    const onVis = () => {
      if (document.visibilityState === "visible" && Date.now() - stamp > 30 * 60_000) {
        setNonce((n) => n + 1);
        setStamp(Date.now());
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [stamp]);

  useEffect(() => {
    if (!loading) setStamp((s) => (nonce > 0 ? Date.now() : Math.min(s, Date.now())));
  }, [loading, nonce]);

  const videos = useMemo(() => {
    const cur = curatedVideos(topic);
    const lv = live.data ?? [];
    const merged = match?.strength === "exact" ? [...cur, ...lv] : [...lv, ...cur];
    const seen = new Set<string>();
    return merged.filter((v) => !bad.has(v.id) && !seen.has(v.id) && !!seen.add(v.id));
  }, [topic, match?.strength, live.data, bad]);

  const readItems = useMemo<Resource[]>(() => {
    const wikiRel = wiki.data?.related ?? [];
    return [...wikiRel.slice(0, 3), ...(devto.data ?? []), ...wikiRel.slice(3)];
  }, [wiki.data, devto.data]);

  const learnItems = useMemo<Resource[]>(() => {
    const c = courses.data ?? [];
    const b = books.data ?? [];
    const out: Resource[] = [];
    for (let i = 0; i < Math.max(c.length, b.length); i++) {
      if (c[i]) out.push(c[i]);
      if (b[i]) out.push(b[i]);
    }
    return out;
  }, [courses.data, books.data]);

  const overview = wiki.data?.overview ?? null;
  const nothingFound = !loading && !videos.length && !readItems.length && !learnItems.length && !overview;

  /* ───── SEO ───── */
  const description = overview
    ? `${truncate(overview.extract, 150)} Free videos, guides, books, tips and a learning plan for ${name}.`
    : `Learn ${name} for free: beginner videos, articles, books, courses, practical tips and a step-by-step plan, all in one place.`;
  const ld = useMemo(() => {
    const url = absUrl(`?q=${encodeURIComponent(q)}`);
    const crumbs = [{ name: "Home", item: absUrl("") }];
    if (cat) crumbs.push({ name: cat.name, item: absUrl(`?cat=${cat.id}`) });
    crumbs.push({ name: `Learn ${name}`, item: url });
    const listItems = [
      ...videos.slice(0, 5).map((v) => ({ name: v.title, url: ytWatch(v.id) })),
      ...[...learnItems, ...readItems].slice(0, 5).map((r) => ({ name: r.title, url: r.url })),
    ];
    return [
      {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: crumbs.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: c.item })),
      },
      {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        name: `Learn ${name} – free videos, courses, books & tips`,
        url,
        description,
        about: name,
        mainEntity: {
          "@type": "ItemList",
          itemListElement: listItems.map((l, i) => ({ "@type": "ListItem", position: i + 1, name: l.name, url: l.url })),
        },
      },
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, name, cat?.id, videos.length, learnItems.length, readItems.length, description]);

  useSEO({
    title: `Learn ${name} — Free Videos, Courses, Books & Tips | ${SITE.name}`,
    description,
    search: `?q=${encodeURIComponent(q)}`,
    noindex: piracy || nothingFound,
    jsonLd: ld,
  });

  /* ───── Roadmap steps built from the real resources found ───── */
  const first = videos[0];
  const firstLearn = learnItems[0];
  const steps: RoadStep[] = [
    {
      icon: "🌍",
      title: "Get the big picture",
      text: `Skim a short overview of ${name} so the key terms make sense.`,
      label: "Read the overview",
      href: overview?.url ?? platform("wikipedia", q),
    },
    {
      icon: "▶️",
      title: "Watch a beginner crash course",
      text: first ? `Start with “${truncate(first.title, 60)}”.` : "Pick one highly-viewed beginner video and watch it start to finish.",
      label: first ? "Play it here" : "Find tutorials",
      onClick: first ? () => setPlaying(first) : undefined,
      href: first ? undefined : platform("youtube", q),
    },
    {
      icon: "🎓",
      title: "Follow one free course or book",
      text: firstLearn ? `Try “${truncate(firstLearn.title, 60)}” on ${firstLearn.source}.` : "Choose a single structured resource and finish it before hopping to another.",
      label: firstLearn ? "Open it" : "Browse free courses",
      href: firstLearn?.url ?? platform("classcentral", q),
    },
    {
      icon: "⏱️",
      title: "Practice 20 minutes a day",
      text: "Small and daily beats long and rare. Use the tips for a simple routine.",
      label: "See practice tips",
      tab: "tips",
    },
    {
      icon: "🛠️",
      title: "Build something small & share it",
      text: "Apply what you learned in a mini project, then ask a community for feedback.",
      label: "Find a community",
      href: platform("reddit", q),
    },
  ];

  const share = async () => {
    const url = location.href;
    const nav = navigator as Navigator & { share?: (d: ShareData) => Promise<void> };
    if (nav.share) {
      try {
        await nav.share({ title: `Learn ${name} – ${SITE.name}`, text: `Free videos, courses and tips to learn ${name}`, url });
        return;
      } catch (e) {
        if ((e as Error).name === "AbortError") return;
      }
    }
    toast((await copyText(url)) ? "Link copied to clipboard" : "Couldn't copy the link");
  };

  const refresh = () => {
    setNonce((n) => n + 1);
    setStamp(Date.now());
    toast("Refreshing live results…", "info");
  };

  const related = topic ? relatedTopics(topic, name, 8).map((t) => ({ label: t.name, emoji: t.emoji })) : (wiki.data?.related ?? []).slice(0, 6).map((r) => ({ label: r.title.replace(/\s*\(.*?\)\s*/g, " ").trim(), emoji: "🔗" }));

  if (piracy && !q) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <div className="text-5xl">🛡️</div>
        <h1 className="font-display mt-4 text-3xl font-bold">We only link to legitimate learning resources</h1>
        <p className="mt-3 text-muted">Cracked or pirated software isn't something we'll ever show. Try searching for the skill itself, like “photoshop” or “video editing” — there are great free tutorials and free tools.</p>
      </div>
    );
  }

  const roadmap = <Roadmap name={name} q={q} steps={steps} />;

  return (
    <div className="relative">
      <div className="aurora -top-24 right-1/4 h-[300px] w-[300px] bg-brand" />
      <div className="relative mx-auto max-w-7xl px-4 pb-6 pt-8 sm:px-6">
        {/* breadcrumb + title */}
        <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1.5 text-sm text-muted">
          <Link to={{ name: "home" }} className="hover:text-ink">Home</Link>
          {cat && (
            <>
              <span>/</span>
              <Link to={{ name: "category", id: cat.id }} className="hover:text-ink">{cat.name}</Link>
            </>
          )}
          <span>/</span>
          <span className="text-ink">{name}</span>
        </nav>

        <div className="mt-5 flex flex-wrap items-end justify-between gap-4">
          <div className="min-w-0">
            <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
              Learn <span className="text-gradient">{topic && match?.strength === "exact" ? `${topic.emoji} ${name}` : name}</span>
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-muted sm:text-base">Videos, reading, free courses and books, practical tips and a plan — everything to start learning {name} today.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-2 rounded-full border border-line bg-surface/70 px-3 py-1.5 text-xs text-muted" aria-live="polite">
              <span className={cn("h-2 w-2 rounded-full", loading ? "animate-pulse bg-amber-400" : "bg-good")} />
              {loading ? "Fetching live results…" : `Live · updated ${timeAgo(stamp)}`}
            </span>
            <button type="button" onClick={refresh} disabled={loading} className="btn-ghost h-9 rounded-xl px-3 text-sm disabled:opacity-60" aria-label="Refresh live results">
              <RefreshIcon size={15} className={loading ? "animate-spin" : ""} /> Refresh
            </button>
            <button type="button" onClick={share} className="btn-ghost h-9 rounded-xl px-3 text-sm" aria-label="Share this page">
              <ShareIcon size={15} /> Share
            </button>
          </div>
        </div>

        {piracy && (
          <div className="mt-5 flex gap-3 rounded-2xl border border-amber-400/40 bg-amber-400/10 p-4 text-sm" role="note">
            <ShieldIcon size={20} className="shrink-0 text-amber-500" />
            <p>
              <strong className="font-semibold">Heads-up:</strong> we don't link to cracked or pirated software. We searched for <strong>“{q}”</strong> instead and show only legitimate, free resources.
            </p>
          </div>
        )}
      </div>

      {/* tabs */}
      <div className="sticky top-[7.5rem] z-30 border-y border-line/70 bg-bg/80 backdrop-blur-xl md:top-16">
        <nav className="scroll-x mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 py-2 sm:px-6" aria-label="Result sections">
          {TABS.map((t) => (
            <Link
              key={t.id}
              to={searchRoute(q, t.id)}
              scroll={false}
              aria-current={tab === t.id ? "page" : undefined}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition",
                tab === t.id ? "bg-brand text-white shadow-lg shadow-brand/25" : "text-muted hover:bg-surface2 hover:text-ink"
              )}
            >
              <span aria-hidden="true">{t.icon}</span>
              {t.label}
              {t.id === "videos" && videos.length > 0 && <span className={cn("rounded-full px-1.5 text-[11px]", tab === t.id ? "bg-white/25" : "bg-surface2")}>{videos.length}</span>}
            </Link>
          ))}
        </nav>
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {nothingFound && (
          <div className="mb-8">
            <EmptyState icon="🧐" title={`We couldn't find live results for “${q}”`}>
              <p>Check the spelling or try a broader word (for example “guitar” instead of “fingerstyle guitar chords”). The direct links below always work.</p>
            </EmptyState>
          </div>
        )}

        {tab === "all" && (
          <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_340px]">
            <div className="min-w-0 space-y-12">
              <OverviewCard overview={overview} loading={wiki.status === "loading"} name={name} q={q} />
              <div className="lg:hidden">{roadmap}</div>

              <Section id="videos-h" eyebrow="Watch" title="Beginner-friendly videos" desc="Click any video to watch right here — no ads-maze, no redirects." q={q} seeAll="videos">
                <VideosBlock videos={videos} loading={live.status === "loading"} limit={6} q={q} onPlay={setPlaying} onBad={(id) => setBad((s) => new Set(s).add(id))} />
              </Section>

              <Section id="read-h" eyebrow="Read" title="Guides & articles" desc="Fresh articles and encyclopedia pages to deepen your understanding." q={q} seeAll="read">
                <ResourceGrid items={readItems} loading={devto.status === "loading" || wiki.status === "loading"} limit={6} empty={<NoArticles q={q} />} />
              </Section>

              <Section id="learn-h" eyebrow="Study" title="Free courses & books" desc="Open textbooks, free-to-borrow books and community-built courses." q={q} seeAll="learn">
                <ResourceGrid items={learnItems} loading={courses.status === "loading" || books.status === "loading"} limit={6} empty={<NoLearn q={q} />} />
              </Section>

              <Section id="tips-h" eyebrow="Tips" title="Tips that actually help" q={q} seeAll="tips">
                <TipsBlock name={name} catId={cat?.id} limit={4} />
              </Section>
            </div>

            <aside className="space-y-6 lg:sticky lg:top-36 lg:max-h-[calc(100vh-10rem)] lg:self-start lg:overflow-y-auto lg:pr-1">
              <div className="hidden lg:block">{roadmap}</div>

              {related.length > 0 && (
                <div className="card rounded-3xl p-5">
                  <h2 className="font-display text-base font-bold">Related skills</h2>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {related.map((r) => (
                      <Link key={r.label} to={searchRoute(r.label)} className="chip rounded-full px-3 py-1.5 text-xs font-medium">
                        {r.emoji} {r.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              <div className="card rounded-3xl p-5">
                <div className="mb-2 flex items-center justify-between">
                  <h2 className="font-display text-base font-bold">Quick links</h2>
                  <Link to={searchRoute(q, "links")} scroll={false} className="text-xs font-semibold text-brand hover:underline">All links →</Link>
                </div>
                <LinksBlock q={q} catId={cat?.id} compact />
              </div>

              <div className="rounded-3xl border border-good/30 bg-good/[0.06] p-5 text-sm">
                <p className="flex items-center gap-2 font-semibold">
                  <ShieldIcon size={18} className="text-good" /> Link Guard is on
                </p>
                <p className="mt-1.5 text-xs leading-relaxed text-muted">Live sources, embed-checked videos, auto-hidden dead thumbnails and a piracy filter keep every link safe and working.</p>
              </div>
            </aside>
          </div>
        )}

        {tab === "videos" && (
          <Section id="videos-all" title={`${name} videos`} desc="Verified beginner courses first, then the latest live results from YouTube.">
            <VideosBlock videos={videos} loading={live.status === "loading"} q={q} onPlay={setPlaying} onBad={(id) => setBad((s) => new Set(s).add(id))} />
          </Section>
        )}

        {tab === "read" && (
          <Section id="read-all" title="Guides & articles" desc="Articles from DEV Community and encyclopedia pages from Wikipedia.">
            <ResourceGrid items={readItems} loading={devto.status === "loading" || wiki.status === "loading"} empty={<NoArticles q={q} />} />
          </Section>
        )}

        {tab === "learn" && (
          <div className="space-y-12">
            <Section id="courses-all" title="Free courses" desc="Community-built learning projects from Wikiversity.">
              <ResourceGrid items={courses.data ?? []} loading={courses.status === "loading"} empty={<NoLearn q={q} />} />
            </Section>
            <Section id="books-all" title="Free books" desc="Open textbooks from Wikibooks and books you can read or borrow free on Open Library.">
              <ResourceGrid items={books.data ?? []} loading={books.status === "loading"} empty={<NoLearn q={q} books />} />
            </Section>
            <Section id="plat-all" title="More free course platforms" desc="Top places for structured, free learning.">
              <LinksBlock q={q} catId={cat?.id} />
            </Section>
          </div>
        )}

        {tab === "tips" && (
          <div className="space-y-12">
            <Section id="tips-all" eyebrow="Tips" title={`How to learn ${name} faster`} desc={cat ? `Advice tailored for ${cat.name.toLowerCase()}, plus proven learning techniques.` : "Proven learning techniques that work for any skill."}>
              <TipsBlock name={name} catId={cat?.id} />
            </Section>
            <Section id="plan-all" eyebrow="Plan" title="A simple 4-week plan">
              <PlanBlock name={name} />
            </Section>
            <Section id="mistakes-all" eyebrow="Avoid" title="Common beginner mistakes">
              <MistakesBlock />
            </Section>
          </div>
        )}

        {tab === "links" && (
          <div className="space-y-10">
            <Section id="links-all" eyebrow="Direct links" title={`Jump straight to the best places to learn ${name}`} desc="Every link is a search on the official website — they open in a new tab and can't go stale.">
              <LinksBlock q={q} catId={cat?.id} />
            </Section>
            <Reveal>
              <div className="rounded-3xl border border-line bg-surface/50 p-6">
                <h2 className="font-display mb-4 flex items-center gap-2 text-lg font-bold">
                  <ShieldIcon size={20} className="text-good" /> How we keep links working
                </h2>
                <LinkGuardCard />
              </div>
            </Reveal>
          </div>
        )}
      </div>

      {playing && <VideoModal video={playing} onClose={() => setPlaying(null)} />}
    </div>
  );
}

function NoArticles({ q }: { q: string }) {
  return (
    <EmptyState icon="📰" title="No articles found for this exact phrase">
      Try a broader term, or search directly on{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("wikipedia", q)} target="_blank" rel="noopener noreferrer">Wikipedia</a>,{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("medium", q)} target="_blank" rel="noopener noreferrer">Medium</a> or{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("reddit", q)} target="_blank" rel="noopener noreferrer">Reddit</a>.
    </EmptyState>
  );
}

function NoLearn({ q, books }: { q: string; books?: boolean }) {
  return (
    <EmptyState icon={books ? "📖" : "🎓"} title={books ? "No free books found for this phrase" : "No community courses found for this phrase"}>
      Try these instead:{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("classcentral", q)} target="_blank" rel="noopener noreferrer">Class Central</a>,{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("ocw", q)} target="_blank" rel="noopener noreferrer">MIT OpenCourseWare</a>,{" "}
      <a className="font-semibold text-brand hover:underline" href={platform("openlibrary", q)} target="_blank" rel="noopener noreferrer">Open Library</a>.
    </EmptyState>
  );
}
