import { useMemo, useState, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { platformsFor, youtubeSearchUrl, type PlatformKind } from "@/lib/links";
import { Link, searchRoute } from "@/lib/router";
import { toggleStep, useProgress } from "@/lib/store";
import { buildPlan, getTips, MISTAKES } from "@/lib/tips";
import type { Resource, Tab, Video } from "@/lib/types";
import { EmptyState, PlatformCard, ResourceCard, TipCard, VideoCard } from "./Cards";
import { ArrowRightIcon, CheckIcon, ExternalIcon, PlayIcon } from "./Icons";
import { Pill, SectionHeading, SkeletonGrid } from "./Ui";

/* ───────── Section shell with a "See all" link ───────── */
export function Section({
  id,
  eyebrow,
  title,
  desc,
  q,
  seeAll,
  children,
}: {
  id: string;
  eyebrow?: string;
  title: ReactNode;
  desc?: ReactNode;
  q?: string;
  seeAll?: Tab;
  children: ReactNode;
}) {
  return (
    <section aria-labelledby={id} className="scroll-mt-32">
      <SectionHeading
        id={id}
        eyebrow={eyebrow}
        title={title}
        desc={desc}
        action={
          seeAll && q ? (
            <Link to={searchRoute(q, seeAll)} scroll={false} className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand hover:gap-2.5">
              See all <ArrowRightIcon size={15} />
            </Link>
          ) : undefined
        }
      />
      {children}
    </section>
  );
}

/* ───────── Videos ───────── */
export function VideosBlock({
  videos,
  loading,
  limit,
  q,
  onPlay,
  onBad,
}: {
  videos: Video[];
  loading: boolean;
  limit?: number;
  q: string;
  onPlay: (v: Video) => void;
  onBad: (id: string) => void;
}) {
  const shown = limit ? videos.slice(0, limit) : videos;
  if (!shown.length && loading) return <SkeletonGrid count={limit ?? 6} />;
  return (
    <div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {shown.map((v) => (
          <VideoCard key={v.id} video={v} onPlay={onPlay} onBad={onBad} />
        ))}
        <a
          href={youtubeSearchUrl(q)}
          target="_blank"
          rel="noopener noreferrer"
          className="card group flex min-h-[200px] flex-col items-center justify-center gap-3 rounded-2xl border-dashed p-6 text-center"
        >
          <span className="grid h-14 w-14 place-items-center rounded-full bg-red-500/15 text-red-500 transition group-hover:scale-110">
            <PlayIcon size={24} />
          </span>
          <span className="text-sm font-semibold">
            {shown.length ? "More tutorials on YouTube" : "Search YouTube for tutorials"}
          </span>
          <span className="flex items-center gap-1 text-xs text-muted">
            Opens YouTube in a new tab <ExternalIcon size={12} />
          </span>
        </a>
      </div>
      {loading && shown.length > 0 && <p className="mt-3 text-xs text-muted">Searching for even more videos…</p>}
      {!loading && shown.length === 0 && (
        <p className="mt-3 text-sm text-muted">Live video search didn't return anything this time — the YouTube link above always works.</p>
      )}
    </div>
  );
}

/* ───────── Generic resource grid ───────── */
export function ResourceGrid({
  items,
  loading,
  limit,
  empty,
}: {
  items: Resource[];
  loading: boolean;
  limit?: number;
  empty: ReactNode;
}) {
  const shown = limit ? items.slice(0, limit) : items;
  if (!shown.length && loading) return <SkeletonGrid count={limit ?? 6} aspect="aspect-[16/9]" />;
  if (!shown.length) return <>{empty}</>;
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {shown.map((r) => (
        <ResourceCard key={r.id} r={r} />
      ))}
    </div>
  );
}

/* ───────── Tips ───────── */
export function TipsBlock({ name, catId, limit }: { name: string; catId?: string; limit?: number }) {
  const { specific, general } = useMemo(() => getTips(name, catId), [name, catId]);
  const all = [...specific, ...general];
  const shown = limit ? all.slice(0, limit) : all;
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {shown.map((t, i) => (
        <TipCard key={t.title} tip={t} accent={i < specific.length} />
      ))}
    </div>
  );
}

export function MistakesBlock() {
  return (
    <ul className="space-y-2.5">
      {MISTAKES.map((m) => (
        <li key={m} className="flex gap-3 rounded-2xl border border-line bg-surface/60 p-3.5 text-sm leading-relaxed">
          <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-red-500/15 text-xs font-bold text-red-500">!</span>
          {m}
        </li>
      ))}
    </ul>
  );
}

export function PlanBlock({ name }: { name: string }) {
  const plan = useMemo(() => buildPlan(name), [name]);
  return (
    <ol className="grid gap-4 md:grid-cols-2">
      {plan.map((w, i) => (
        <li key={w.week} className="card relative rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand/15 font-display text-sm font-bold text-brand">{i + 1}</span>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted">{w.week}</p>
              <h3 className="font-display text-base font-bold">{w.focus}</h3>
            </div>
          </div>
          <ul className="mt-3 space-y-2 text-sm text-muted">
            {w.tasks.map((t) => (
              <li key={t} className="flex gap-2.5">
                <span className="mt-1 text-brand">▸</span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </li>
      ))}
    </ol>
  );
}

/* ───────── Direct links hub ───────── */
export function LinksBlock({ q, catId, compact }: { q: string; catId?: string; compact?: boolean }) {
  const [freeOnly, setFreeOnly] = useState(true);
  const all = useMemo(() => platformsFor(q, catId), [q, catId]);
  const list = all.filter((p) => !freeOnly || p.price === "free");
  const kinds: PlatformKind[] = ["Videos", "Courses", "Articles", "Books", "Practice", "Community"];

  if (compact) {
    return (
      <ul className="space-y-2">
        {all
          .filter((p) => p.price === "free")
          .slice(0, 6)
          .map((p) => (
            <li key={p.id}>
              <a
                href={p.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-3 rounded-xl border border-transparent px-2.5 py-2 transition hover:border-line hover:bg-surface2"
              >
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-surface2 text-lg">{p.emoji}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{p.name}</span>
                  <span className="block truncate text-xs text-muted">{p.desc}</span>
                </span>
                <ExternalIcon size={14} className="text-muted group-hover:text-brand" />
              </a>
            </li>
          ))}
      </ul>
    );
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="inline-flex rounded-xl border border-line bg-surface p-1 text-sm" role="group" aria-label="Filter links">
          {[
            [true, "Free only"],
            [false, "Everything"],
          ].map(([v, label]) => (
            <button
              key={String(label)}
              type="button"
              aria-pressed={freeOnly === v}
              onClick={() => setFreeOnly(v as boolean)}
              className={cn("rounded-lg px-3.5 py-1.5 font-medium transition", freeOnly === v ? "bg-brand text-white shadow" : "text-muted hover:text-ink")}
            >
              {label as string}
            </button>
          ))}
        </div>
        <p className="flex items-center gap-1.5 text-xs text-muted">
          <CheckIcon size={13} className="text-good" /> Each link opens a search for “{q}” on the official site, so it can't be a dead page.
        </p>
      </div>
      <div className="space-y-8">
        {kinds.map((k) => {
          const items = list.filter((p) => p.kind === k);
          if (!items.length) return null;
          return (
            <div key={k}>
              <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted">
                {k} <Pill>{items.length}</Pill>
              </h3>
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {items.map((p) => (
                  <PlatformCard key={p.id} p={p} href={p.href} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ───────── Roadmap with persisted progress ───────── */
export interface RoadStep {
  icon: string;
  title: string;
  text: string;
  label: string;
  href?: string;
  onClick?: () => void;
  tab?: Tab;
}

export function Roadmap({ name, q, steps }: { name: string; q: string; steps: RoadStep[] }) {
  const progress = useProgress();
  const done = progress[name.toLowerCase()] || [];
  const pct = Math.round((done.filter((i) => i < steps.length).length / steps.length) * 100);

  return (
    <div className="card rounded-3xl p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold">Your {name} roadmap</h2>
          <p className="text-xs text-muted">Tick steps off as you go — progress is saved.</p>
        </div>
        <span className="font-display text-xl font-extrabold text-gradient">{pct}%</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-surface2" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Roadmap progress">
        <div className="h-full rounded-full bg-gradient-to-r from-brand to-brand2 transition-all duration-500" style={{ width: pct + "%" }} />
      </div>
      <ol className="mt-4 space-y-2">
        {steps.map((s, i) => {
          const checked = done.includes(i);
          return (
            <li key={s.title} className={cn("flex gap-3 rounded-2xl border p-3 transition", checked ? "border-good/30 bg-good/[0.06]" : "border-line bg-surface/50")}>
              <button
                type="button"
                role="checkbox"
                aria-checked={checked}
                aria-label={`Mark “${s.title}” as ${checked ? "not done" : "done"}`}
                onClick={() => toggleStep(name, i)}
                className={cn("mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition", checked ? "border-good bg-good text-white" : "border-line hover:border-brand")}
              >
                {checked && <CheckIcon size={13} />}
              </button>
              <div className="min-w-0 flex-1">
                <p className={cn("text-sm font-semibold", checked && "text-muted line-through decoration-good/60")}>
                  <span className="mr-1.5">{s.icon}</span>
                  {s.title}
                </p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted">{s.text}</p>
                {s.href ? (
                  <a href={s.href} target="_blank" rel="noopener noreferrer" className="mt-1.5 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">
                    {s.label} <ExternalIcon size={11} />
                  </a>
                ) : s.onClick ? (
                  <button type="button" onClick={s.onClick} className="mt-1.5 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">
                    {s.label} <PlayIcon size={11} />
                  </button>
                ) : s.tab ? (
                  <Link to={searchRoute(q, s.tab)} className="mt-1.5 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">
                    {s.label} <ArrowRightIcon size={11} />
                  </Link>
                ) : null}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export { EmptyState };
