import { useId } from "react";

export function LogoMark({ size = 32 }: { size?: number }) {
  const id = useId();
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8b6cff" />
          <stop offset="0.55" stopColor="#22d3ee" />
          <stop offset="1" stopColor="#f472b6" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="#0b0b1a" />
      <circle cx="32" cy="32" r="12" fill={`url(#${id})`} />
      <ellipse cx="32" cy="32" rx="25" ry="9" fill="none" stroke={`url(#${id})`} strokeWidth="3" transform="rotate(-24 32 32)" />
      <circle cx="53" cy="23" r="4" fill="#fff" />
    </svg>
  );
}
