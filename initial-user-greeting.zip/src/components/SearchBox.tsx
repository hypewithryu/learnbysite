import { useEffect, useMemo, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { cn } from "@/utils/cn";
import { suggestRemote } from "@/lib/api";
import { addRecent, clearRecent, useRecent } from "@/lib/store";
import { navigate, searchRoute } from "@/lib/router";
import { normalize } from "@/lib/text";
import { topics } from "@/lib/topics";
import { ClockIcon, GlobeIcon, SearchIcon, XIcon } from "./Icons";

interface Suggestion {
  label: string;
  query: string;
  kind: "recent" | "topic" | "web";
  emoji?: string;
}

const EXAMPLES = ["guitar", "python", "Spanish", "photoshop", "yoga", "investing", "chess", "public speaking", "baking", "machine learning"];
const POPULAR = ["Python", "Guitar", "Spanish", "Photoshop", "Yoga", "Investing"];

interface Props {
  size?: "lg" | "sm";
  initial?: string;
  autoFocus?: boolean;
  hotkey?: boolean;
  className?: string;
}

export function SearchBox({ size = "lg", initial = "", autoFocus, hotkey, className }: Props) {
  const [value, setValue] = useState(initial);
  const [focused, setFocused] = useState(false);
  const [remote, setRemote] = useState<string[]>([]);
  const [active, setActive] = useState(-1);
  const [ph, setPh] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const recent = useRecent();
  const listId = useMemo(() => "sb-" + Math.random().toString(36).slice(2, 8), []);

  useEffect(() => setValue(initial), [initial]);

  // "/" focuses the search box from anywhere
  useEffect(() => {
    if (!hotkey) return;
    const onKey = (e: globalThis.KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing = el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable);
      if (e.key === "/" && !typing && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hotkey]);

  // rotating placeholder
  useEffect(() => {
    if (focused || value) return;
    const t = setInterval(() => setPh((p) => (p + 1) % EXAMPLES.length), 2400);
    return () => clearInterval(t);
  }, [focused, value]);

  // live suggestions (debounced)
  useEffect(() => {
    const q = value.trim();
    if (q.length < 2) {
      setRemote([]);
      return;
    }
    let alive = true;
    const t = setTimeout(() => {
      suggestRemote(q)
        .then((r) => alive && setRemote(r))
        .catch(() => alive && setRemote([]));
    }, 260);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [value]);

  const suggestions: Suggestion[] = useMemo(() => {
    const q = normalize(value);
    if (!q) {
      const rec = recent.slice(0, 4).map<Suggestion>((r) => ({ label: r, query: r, kind: "recent" }));
      const pop = POPULAR.map<Suggestion>((p) => {
        const t = topics.find((x) => x.name === p);
        return { label: p, query: p, kind: "topic", emoji: t?.emoji };
      });
      return [...rec, ...pop].slice(0, 8);
    }
    const local = topics
      .filter((t) => [t.name, ...t.aliases].some((n) => normalize(n).includes(q)))
      .slice(0, 5)
      .map<Suggestion>((t) => ({ label: t.name, query: t.name, kind: "topic", emoji: t.emoji }));
    const seen = new Set(local.map((l) => normalize(l.label)));
    const web: Suggestion[] = [];
    for (const r of remote) {
      const clean = r.replace(/\s*\(.*?\)\s*/g, " ").replace(/\s+/g, " ").trim();
      if (clean && !seen.has(normalize(clean))) {
        seen.add(normalize(clean));
        web.push({ label: clean, query: clean, kind: "web" });
      }
    }
    return [...local, ...web].slice(0, 8);
  }, [value, remote, recent]);

  const submit = (q: string) => {
    const query = q.trim();
    if (!query) {
      inputRef.current?.focus();
      return;
    }
    addRecent(query);
    setFocused(false);
    inputRef.current?.blur();
    navigate(searchRoute(query));
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (active >= 0 && suggestions[active]) submit(suggestions[active].query);
    else submit(value);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setFocused(true);
      setActive((a) => (a + 1) % Math.max(1, suggestions.length));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => (a <= 0 ? suggestions.length - 1 : a - 1));
    } else if (e.key === "Escape") {
      setFocused(false);
      inputRef.current?.blur();
    }
  };

  const lg = size === "lg";
  const open = focused && suggestions.length > 0;

  return (
    <form
      role="search"
      onSubmit={onSubmit}
      className={cn("relative w-full", className)}
      onMouseDown={(e) => {
        // keep input focused while clicking suggestions
        if ((e.target as HTMLElement).closest("[data-suggest]")) e.preventDefault();
      }}
    >
      <div
        className={cn(
          "group flex items-center gap-2 border bg-surface/90 backdrop-blur transition-all",
          focused ? "border-brand shadow-[0_0_0_4px_color-mix(in_oklab,var(--brand)_22%,transparent),0_20px_60px_-20px_var(--glow)]" : "border-line shadow-[0_10px_40px_-20px_var(--glow)]",
          lg ? "h-14 rounded-2xl pl-5 pr-2 sm:h-[68px]" : "h-11 rounded-xl pl-3.5 pr-1.5"
        )}
      >
        <SearchIcon size={lg ? 22 : 18} className={cn("shrink-0 transition-colors", focused ? "text-brand" : "text-muted")} />
        <input
          ref={inputRef}
          type="search"
          name="q"
          value={value}
          autoFocus={autoFocus}
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          enterKeyHint="search"
          maxLength={120}
          aria-label="Search any skill or topic you want to learn"
          aria-autocomplete="list"
          aria-expanded={open}
          aria-controls={listId}
          aria-activedescendant={active >= 0 ? `${listId}-${active}` : undefined}
          role="combobox"
          placeholder={focused ? "What do you want to learn?" : `Try “${EXAMPLES[ph]}”…`}
          onChange={(e) => {
            setValue(e.target.value);
            setActive(-1);
            window.dispatchEvent(new Event("lo:energy"));
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={onKeyDown}
          className={cn(
            "min-w-0 flex-1 bg-transparent font-medium text-ink outline-none placeholder:text-muted/80 [&::-webkit-search-cancel-button]:hidden",
            lg ? "text-base sm:text-lg" : "text-sm"
          )}
        />
        {value && (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => {
              setValue("");
              inputRef.current?.focus();
            }}
            className="grid h-8 w-8 place-items-center rounded-full text-muted transition hover:bg-surface2 hover:text-ink"
          >
            <XIcon size={16} />
          </button>
        )}
        <button
          type="submit"
          className={cn("btn-primary shrink-0", lg ? "h-10 rounded-xl px-4 text-sm sm:h-[52px] sm:px-6 sm:text-base" : "h-8 rounded-lg px-3 text-xs")}
        >
          <span className={lg ? "hidden sm:inline" : "hidden"}>Search</span>
          <SearchIcon size={lg ? 18 : 15} className={lg ? "sm:hidden" : ""} />
          {!lg && <span>Go</span>}
        </button>
      </div>

      {open && (
        <ul
          id={listId}
          role="listbox"
          data-suggest
          className="animate-pop-in absolute left-0 right-0 top-full z-50 mt-2 max-h-[min(420px,60vh)] overflow-auto rounded-2xl border border-line bg-surface p-1.5 shadow-2xl shadow-black/30"
        >
          {!value.trim() && (
            <li className="flex items-center justify-between px-3 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wider text-muted" role="presentation">
              <span>{recent.length ? "Recent & popular" : "Popular skills"}</span>
              {recent.length > 0 && (
                <button type="button" onClick={clearRecent} className="normal-case tracking-normal text-brand hover:underline">
                  Clear history
                </button>
              )}
            </li>
          )}
          {suggestions.map((s, i) => (
            <li key={s.kind + s.label} role="presentation">
              <button
                type="button"
                id={`${listId}-${i}`}
                role="option"
                aria-selected={i === active}
                onMouseEnter={() => setActive(i)}
                onClick={() => submit(s.query)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-colors",
                  i === active ? "bg-brand/12 text-ink" : "hover:bg-surface2"
                )}
              >
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-surface2 text-base">
                  {s.kind === "recent" ? <ClockIcon size={15} className="text-muted" /> : s.kind === "web" ? <GlobeIcon size={15} className="text-muted" /> : s.emoji}
                </span>
                <span className="flex-1 truncate font-medium">{s.label}</span>
                <span className="text-[11px] text-muted">{s.kind === "recent" ? "Recent" : s.kind === "web" ? "Suggestion" : "Skill"}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}
