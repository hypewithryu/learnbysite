import { useEffect, useRef, useState } from "react";
import { SITE } from "@/lib/config";
import { Link } from "@/lib/router";
import { toggleTheme, useSaved, useTheme } from "@/lib/store";
import { categories } from "@/lib/topics";
import type { Route } from "@/lib/types";
import { BookmarkIcon, MoonIcon, SunIcon } from "./Icons";
import { LogoMark } from "./Logo";
import { SearchBox } from "./SearchBox";

function CategoryMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent) {
        if (e.key === "Escape") setOpen(false);
      } else if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", close);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", close);
    };
  }, [open]);
  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="btn-ghost h-10 rounded-xl px-3.5 text-sm"
      >
        <span className="hidden sm:inline">Categories</span>
        <span className="sm:hidden" aria-label="Categories">
          ☰
        </span>
        <svg width="12" height="12" viewBox="0 0 12 12" className={open ? "rotate-180 transition" : "transition"} aria-hidden="true">
          <path d="m2 4 4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </button>
      {open && (
        <div className="animate-pop-in absolute right-0 top-full z-50 mt-2 w-[min(92vw,360px)] rounded-2xl border border-line bg-surface p-2 shadow-2xl shadow-black/30">
          <div className="grid grid-cols-2 gap-1">
            {categories.map((c) => (
              <Link
                key={c.id}
                to={{ name: "category", id: c.id }}
                onClick={() => setOpen(false)}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium transition hover:bg-surface2"
              >
                <span className="grid h-8 w-8 place-items-center rounded-lg text-lg" style={{ background: c.color + "26" }}>
                  {c.emoji}
                </span>
                <span className="leading-tight">{c.name}</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function Header({ route, onOpenSaved }: { route: Route; onOpenSaved: () => void }) {
  const saved = useSaved();
  const theme = useTheme();
  const isHome = route.name === "home";
  const q = route.name === "search" ? route.q : "";

  return (
    <header className="sticky top-0 z-40 border-b border-line/70 glass" role="banner">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <Link to={{ name: "home" }} className="flex shrink-0 items-center gap-2.5" aria-label={`${SITE.name} – home`}>
          <LogoMark size={34} />
          <span className="font-display text-lg font-bold tracking-tight">
            {SITE.name.slice(0, 5)}
            <span className="text-gradient">{SITE.name.slice(5)}</span>
          </span>
        </Link>

        {!isHome && (
          <div className="mx-auto hidden w-full max-w-xl flex-1 md:block">
            <SearchBox size="sm" initial={q} hotkey />
          </div>
        )}

        <nav className="ml-auto flex items-center gap-2" aria-label="Main">
          <CategoryMenu />
          <button
            type="button"
            onClick={onOpenSaved}
            className="btn-ghost relative h-10 rounded-xl px-3 text-sm"
            aria-label={`My learning list (${saved.length} saved)`}
          >
            <BookmarkIcon size={17} filled={saved.length > 0} className={saved.length ? "text-brand" : ""} />
            <span className="hidden sm:inline">Saved</span>
            {saved.length > 0 && (
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-brand px-1 text-[11px] font-bold text-white">{saved.length}</span>
            )}
          </button>
          <button
            type="button"
            onClick={toggleTheme}
            className="btn-ghost h-10 w-10 rounded-xl"
            aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            title={theme === "dark" ? "Light mode" : "Dark mode"}
          >
            {theme === "dark" ? <SunIcon size={18} /> : <MoonIcon size={18} />}
          </button>
        </nav>
      </div>
      {!isHome && (
        <div className="px-4 pb-3 md:hidden">
          <SearchBox size="sm" initial={q} />
        </div>
      )}
    </header>
  );
}
