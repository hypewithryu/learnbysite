import type { ReactNode } from "react";
import { cn } from "@/utils/cn";
import type { Platform } from "@/lib/links";
import { Link, searchRoute } from "@/lib/router";
import { catById, topicThumb } from "@/lib/topics";
import type { Resource, Topic, Video } from "@/lib/types";
import { ytThumb, ytWatch } from "@/lib/text";
import { ExternalIcon, PlayIcon } from "./Icons";
import { Pill, SafeImage, SaveButton, Tilt } from "./Ui";
import type { Tip } from "@/lib/tips";

/* ───────── Topic tile (3D tilt + real video thumbnail) ───────── */
export function TopicCard({ topic, className }: { topic: Topic; className?: string }) {
  const cat = catById(topic.cat);
  const thumb = topicThumb(topic);
  return (
    <Tilt className={className} max={7}>
      <Link
        to={searchRoute(topic.name)}
        className="group relative block aspect-[4/3] overflow-hidden rounded-2xl border border-line bg-surface2 shadow-sm"
        aria-label={`Learn ${topic.name}`}
      >
        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${cat?.color ?? "#8b6cff"}55, transparent)` }} />
        <SafeImage
          src={thumb}
          alt=""
          className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-110"
          fallback={<span />}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
        <span className="tilt-pop absolute left-3 top-3 grid h-10 w-10 place-items-center rounded-xl bg-white/15 text-xl backdrop-blur-md ring-1 ring-white/25">
          {topic.emoji}
        </span>
        <div className="tilt-pop absolute inset-x-0 bottom-0 p-3.5 text-white">
          <p className="font-display text-base font-bold leading-tight drop-shadow sm:text-lg">{topic.name}</p>
          <p className="mt-0.5 text-xs text-white/75">{cat?.name}</p>
        </div>
      </Link>
    </Tilt>
  );
}

/* ───────── Video ───────── */
export function VideoCard({ video, onPlay, onBad }: { video: Video; onPlay: (v: Video) => void; onBad: (id: string) => void }) {
  return (
    <article className="card group overflow-hidden rounded-2xl">
      <button
        type="button"
        onClick={() => onPlay(video)}
        className="relative block aspect-video w-full overflow-hidden bg-surface2"
        aria-label={`Play video: ${video.title}`}
      >
        <SafeImage
          src={ytThumb(video.id, "mq")}
          alt=""
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          fallback={<span />}
          onFail={() => onBad(video.id)}
        />
        <span className="absolute inset-0 grid place-items-center bg-black/0 transition group-hover:bg-black/35">
          <span className="grid h-14 w-14 scale-90 place-items-center rounded-full bg-white/95 pl-0.5 text-black opacity-90 shadow-xl transition group-hover:scale-100 group-hover:opacity-100">
            <PlayIcon size={24} />
          </span>
        </span>
        {video.duration && (
          <span className="absolute bottom-2 right-2 rounded-md bg-black/80 px-1.5 py-0.5 text-[11px] font-semibold text-white">{video.duration}</span>
        )}
        {video.origin === "verified" && (
          <span className="absolute left-2 top-2" title="Checked: this video exists and can be played here">
            <Pill tone="good" className="bg-black/70 backdrop-blur">✓ Verified</Pill>
          </span>
        )}
      </button>
      <div className="flex gap-2 p-3.5">
        <div className="min-w-0 flex-1">
          <h3 className="prose-clamp-2 text-sm font-semibold leading-snug">{video.title}</h3>
          <p className="mt-1.5 truncate text-xs text-muted">{video.channel}</p>
          <p className="truncate text-xs text-muted">{[video.views && `${video.views} views`, video.published].filter(Boolean).join(" · ")}</p>
        </div>
        <SaveButton item={{ id: "yt:" + video.id, title: video.title, url: ytWatch(video.id), kind: "video", source: video.channel, thumb: ytThumb(video.id, "mq") }} />
      </div>
    </article>
  );
}

/* ───────── Article / course / book ───────── */
const KIND_EMOJI: Record<Resource["kind"], string> = { article: "📰", course: "🎓", book: "📖", lecture: "🎬", wiki: "🌐" };

export function ResourceCard({ r }: { r: Resource }) {
  const isBook = r.kind === "book" && r.source === "Open Library";
  return (
    <article className="card group relative flex flex-col overflow-hidden rounded-2xl">
      <a href={r.url} target="_blank" rel="noopener noreferrer" className="flex flex-1 flex-col" aria-label={`${r.title} (opens ${r.source} in a new tab)`}>
        <div className="relative aspect-[16/9] overflow-hidden bg-surface2">
          <SafeImage
            src={r.thumb}
            alt=""
            className={cn("h-full w-full transition duration-500 group-hover:scale-105", isBook ? "object-contain p-3" : "object-cover")}
            fallback={
              <div className="grid h-full w-full place-items-center bg-[linear-gradient(135deg,color-mix(in_oklab,var(--brand)_22%,var(--surface-2)),color-mix(in_oklab,var(--brand-2)_16%,var(--surface-2)))] text-5xl">
                {KIND_EMOJI[r.kind]}
              </div>
            }
          />
          <Pill className="absolute left-2 top-2 bg-surface/85 backdrop-blur">{r.source}</Pill>
          {r.badge && <Pill tone="good" className="absolute right-2 top-2 bg-surface/85 backdrop-blur">{r.badge}</Pill>}
        </div>
        <div className="flex flex-1 flex-col p-3.5">
          <h3 className="prose-clamp-2 text-sm font-semibold leading-snug">{r.title}</h3>
          {r.desc && <p className="prose-clamp-3 mt-1.5 text-xs leading-relaxed text-muted">{r.desc}</p>}
          <div className="mt-auto flex items-center gap-1.5 pr-11 pt-3 text-xs">
            <span className="truncate text-muted">{r.meta}</span>
            <span className="ml-auto flex shrink-0 items-center gap-1 font-semibold text-brand">
              Open <ExternalIcon size={13} />
            </span>
          </div>
        </div>
      </a>
      <SaveButton className="absolute bottom-2.5 right-2.5" item={{ id: r.id, title: r.title, url: r.url, kind: r.kind, source: r.source, thumb: r.thumb }} />
    </article>
  );
}

/* ───────── Tip ───────── */
export function TipCard({ tip, accent }: { tip: Tip; accent?: boolean }) {
  return (
    <div className={cn("card flex gap-3.5 rounded-2xl p-4", accent && "bg-[linear-gradient(135deg,color-mix(in_oklab,var(--brand)_10%,var(--surface)),var(--surface))]")}>
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-surface2 text-2xl">{tip.icon}</span>
      <div>
        <h3 className="text-sm font-semibold">{tip.title}</h3>
        <p className="mt-1 text-sm leading-relaxed text-muted">{tip.body}</p>
      </div>
    </div>
  );
}

/* ───────── Platform link ───────── */
const PRICE: Record<Platform["price"], { label: string; tone: "good" | "brand" | "warn" }> = {
  free: { label: "Free", tone: "good" },
  freemium: { label: "Free + paid", tone: "brand" },
  paid: { label: "Paid", tone: "warn" },
};

export function PlatformCard({ p, href }: { p: Platform; href: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="card group flex items-center gap-3.5 rounded-2xl p-3.5"
      aria-label={`${p.name} – ${p.desc} (opens in a new tab)`}
    >
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-surface2 text-2xl transition group-hover:scale-110">{p.emoji}</span>
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-semibold">{p.name}</span>
          <Pill tone={PRICE[p.price].tone}>{PRICE[p.price].label}</Pill>
        </span>
        <span className="prose-clamp-2 mt-0.5 block text-xs leading-snug text-muted">{p.desc}</span>
      </span>
      <ExternalIcon size={16} className="shrink-0 text-muted transition group-hover:text-brand" />
    </a>
  );
}

/* ───────── Empty / fallback states (never a dead end) ───────── */
export function EmptyState({ icon = "🔎", title, children }: { icon?: string; title: string; children?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-line bg-surface/50 p-6 text-center">
      <div className="text-3xl">{icon}</div>
      <p className="mt-2 text-sm font-semibold">{title}</p>
      {children && <div className="mx-auto mt-2 max-w-md text-sm text-muted">{children}</div>}
    </div>
  );
}
