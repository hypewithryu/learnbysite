import { useMemo } from "react";
import { absUrl, SITE } from "@/lib/config";
import { Link } from "@/lib/router";
import { useSEO } from "@/lib/seo";
import { categories, catById, topicsIn } from "@/lib/topics";
import { TopicCard } from "./Cards";
import { Reveal } from "./Ui";

export default function CategoryPage({ id }: { id: string }) {
  const cat = catById(id);
  const list = cat ? topicsIn(cat.id) : [];

  const ld = useMemo(
    () =>
      cat
        ? [
            {
              "@context": "https://schema.org",
              "@type": "CollectionPage",
              name: `${cat.name} – free courses, videos & tips`,
              url: absUrl(`?cat=${cat.id}`),
              mainEntity: {
                "@type": "ItemList",
                itemListElement: list.map((t, i) => ({
                  "@type": "ListItem",
                  position: i + 1,
                  name: `Learn ${t.name}`,
                  url: absUrl(`?q=${encodeURIComponent(t.name)}`),
                })),
              },
            },
          ]
        : [],
    [cat, list]
  );

  useSEO({
    title: cat ? `${cat.name} — Learn Free: Videos, Courses & Tips | ${SITE.name}` : `Category not found | ${SITE.name}`,
    description: cat ? `${cat.blurb} Browse ${list.length} skills with free videos, articles, books, tips and learning plans.` : SITE.description,
    search: cat ? `?cat=${cat.id}` : "",
    noindex: !cat,
    jsonLd: ld,
  });

  if (!cat) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="text-5xl">🧭</p>
        <h1 className="font-display mt-4 text-3xl font-bold">We couldn't find that category</h1>
        <p className="mt-2 text-muted">Pick one of these instead:</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {categories.map((c) => (
            <Link key={c.id} to={{ name: "category", id: c.id }} className="chip rounded-full px-4 py-2 text-sm font-medium">
              {c.emoji} {c.name}
            </Link>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="aurora -top-20 left-1/4 h-[320px] w-[320px]" style={{ background: cat.color }} />
      <div className="relative mx-auto max-w-7xl px-4 pb-8 pt-10 sm:px-6">
        <nav aria-label="Breadcrumb" className="text-sm text-muted">
          <Link to={{ name: "home" }} className="hover:text-ink">Home</Link> <span className="mx-1">/</span> <span className="text-ink">{cat.name}</span>
        </nav>
        <div className="mt-6 flex items-center gap-4">
          <span className="grid h-16 w-16 place-items-center rounded-2xl text-4xl" style={{ background: `linear-gradient(135deg, ${cat.color}66, ${cat.color}1f)`, boxShadow: `0 14px 40px -14px ${cat.color}` }}>
            {cat.emoji}
          </span>
          <div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight sm:text-5xl">{cat.name}</h1>
            <p className="mt-1.5 max-w-2xl text-muted">{cat.blurb}</p>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {list.map((t, i) => (
            <Reveal key={t.name} delay={(i % 4) * 50}>
              <TopicCard topic={t} />
            </Reveal>
          ))}
        </div>

        <div className="mt-14">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted">More categories</h2>
          <div className="flex flex-wrap gap-2">
            {categories
              .filter((c) => c.id !== cat.id)
              .map((c) => (
                <Link key={c.id} to={{ name: "category", id: c.id }} className="chip rounded-full px-4 py-2 text-sm font-medium">
                  {c.emoji} {c.name}
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
