import { lazy, Suspense, useMemo } from "react";
import { getTrending } from "@/lib/api";
import { absUrl, SITE } from "@/lib/config";
import { Link, navigate, searchRoute } from "@/lib/router";
import { useSEO } from "@/lib/seo";
import { useRecent } from "@/lib/store";
import { catalogStats, categories, catById, skillOfTheDay, topicThumb, topics, topicsIn } from "@/lib/topics";
import { useSource } from "@/lib/useSource";
import { ArrowRightIcon, CheckIcon, ShieldIcon } from "./Icons";
import { SearchBox } from "./SearchBox";
import { TopicCard } from "./Cards";
import { CubeLoader, Pill, Reveal, SafeImage, SectionHeading, Tilt } from "./Ui";

const Scene3D = lazy(() => import("./Scene3D"));

const POPULAR = ["Python", "Guitar", "Spanish", "Photoshop", "Yoga", "Investing", "Chess"];
const FEATURED = ["Python", "Guitar", "Spanish", "Photoshop", "Machine Learning", "Yoga", "Investing", "Cooking", "Video Editing", "Public Speaking", "Piano", "Mathematics"];

export const FAQ: Array<{ q: string; a: string }> = [
  {
    q: `Is ${SITE.name} really free?`,
    a: `Yes. ${SITE.name} is free to use and every resource it surfaces — YouTube videos, Wikipedia, Wikiversity and Wikibooks pages, Open Library books and DEV articles — is free to access. On the Links tab, platforms that also sell content (Coursera, Udemy and others) are clearly labelled “Free + paid” or “Paid”.`,
  },
  {
    q: "Where do the results come from?",
    a: "Live, at the moment you search: Wikipedia, Wikiversity, Wikibooks, Open Library, DEV Community and YouTube. Our catalog of verified beginner videos is also re-checked automatically every week.",
  },
  {
    q: "How do you avoid broken or blocked links?",
    a: "Results are fetched live from their original source, video thumbnails are verified before being shown (dead ones disappear), videos in our catalog are checked with YouTube to make sure they exist and can be embedded, and every section has a fallback direct link to a search page that always works.",
  },
  {
    q: "Do you link to cracked software or pirated courses?",
    a: "Never. A built-in link guard filters out cracks, keygens, torrents and re-uploaded paid courses, and we point people to legitimate free alternatives instead.",
  },
  {
    q: "Does the site update itself?",
    a: "Yes. Search results are always live, the verified video catalog and sitemap refresh on a weekly schedule, and your browser quietly checks for new versions of the site and applies them on your next search — no manual refresh needed.",
  },
  {
    q: "Can I save things and track my progress?",
    a: "Yes. Tap the bookmark on any video, article or book to build your own learning list, and tick off the steps of each skill's roadmap. Everything is stored privately in your browser on your device.",
  },
];

function Hero() {
  const recent = useRecent();
  const onPick = (catId: string) => {
    const list = topicsIn(catId);
    const pick = list[Math.floor(Math.random() * list.length)];
    if (pick) navigate(searchRoute(pick.name));
  };
  return (
    <section className="relative isolate overflow-hidden" aria-labelledby="hero-title">
      <div className="aurora -left-24 -top-32 h-[420px] w-[420px] bg-brand" />
      <div className="aurora -right-20 top-10 h-[380px] w-[380px] bg-brand2" style={{ animationDelay: "-6s" }} />
      <div className="aurora bottom-0 left-1/3 h-[300px] w-[300px] bg-accent" style={{ animationDelay: "-12s" }} />
      <div className="grid-bg absolute inset-0 -z-10" />

      <div className="mx-auto grid max-w-7xl items-center gap-4 px-4 pb-14 pt-10 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-16">
        <div className="relative z-20">
          <Pill tone="brand" className="px-3 py-1 text-xs">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-good" /> Live results · 100% free sources
          </Pill>
          <h1 id="hero-title" className="font-display mt-5 text-[2.6rem] font-extrabold leading-[1.04] tracking-tight sm:text-6xl lg:text-[4.1rem]">
            Learn <span className="text-gradient">anything.</span>
            <br />
            Start in seconds.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
            Type any skill — guitar, Python, Spanish, baking — and get the best free videos, guides, books, tips and a step-by-step plan, all on one clean page.
          </p>

          <div className="mt-8 max-w-2xl">
            <SearchBox size="lg" hotkey />
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="mr-1 text-sm text-muted">Popular:</span>
            {POPULAR.map((name) => {
              const t = topics.find((x) => x.name === name);
              return (
                <Link key={name} to={searchRoute(name)} className="chip rounded-full px-3.5 py-1.5 text-sm font-medium">
                  {t?.emoji} {name}
                </Link>
              );
            })}
          </div>

          {recent.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="mr-1 text-sm text-muted">Continue:</span>
              {recent.slice(0, 4).map((r) => (
                <Link key={r} to={searchRoute(r)} className="chip rounded-full px-3 py-1 text-xs font-medium text-muted">
                  {r}
                </Link>
              ))}
            </div>
          )}

          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted">
            {["Videos, articles, books & tips", "Updates itself automatically", "No cracked or pirated links"].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <span className="grid h-5 w-5 place-items-center rounded-full bg-good/15 text-good">
                  <CheckIcon size={12} />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative mx-auto aspect-square w-full max-w-[520px] lg:max-w-none">
          <Suspense fallback={<CubeLoader />}>
            <Scene3D categories={categories} onPick={onPick} />
          </Suspense>
          <p className="pointer-events-none absolute inset-x-0 bottom-1 text-center text-xs text-muted">
            <span className="rounded-full border border-line bg-surface/70 px-3 py-1 backdrop-blur">Drag to spin · Tap a planet to explore</span>
          </p>
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const row = (hidden: boolean) =>
    topics.map((t) => (
      <Link
        key={(hidden ? "b" : "a") + t.name}
        to={searchRoute(t.name)}
        tabIndex={hidden ? -1 : undefined}
        aria-hidden={hidden || undefined}
        className="chip shrink-0 rounded-full px-4 py-2 text-sm font-medium"
      >
        <span>{t.emoji}</span> {t.name}
      </Link>
    ));
  return (
    <div className="relative overflow-hidden border-y border-line/70 bg-surface/40 py-4 [mask-image:linear-gradient(90deg,transparent,#000_8%,#000_92%,transparent)]" aria-label="Browse skills">
      <div className="flex w-max animate-marquee gap-3 hover:[animation-play-state:paused]">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}

function Today() {
  const topic = useMemo(() => skillOfTheDay(), []);
  const cat = catById(topic.cat);
  const trending = useSource("trending", (force) => getTrending(force));
  return (
    <section className="mx-auto max-w-7xl px-4 pt-16 sm:px-6" aria-label="Today">
      <div className="grid gap-5 lg:grid-cols-2">
        <Reveal>
          <Tilt max={5} className="h-full">
            <Link
              to={searchRoute(topic.name)}
              className="group relative flex h-full min-h-[300px] flex-col justify-end overflow-hidden rounded-3xl border border-line bg-surface2 p-6 text-white"
            >
              <SafeImage src={topicThumb(topic)} alt="" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" fallback={<span />} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10" />
              <div className="tilt-pop relative">
                <Pill className="border-white/30 bg-white/15 text-white backdrop-blur">⭐ Skill of the day</Pill>
                <h2 className="font-display mt-3 text-3xl font-extrabold sm:text-4xl">
                  {topic.emoji} {topic.name}
                </h2>
                <p className="mt-1.5 max-w-md text-sm text-white/80">
                  A fresh skill spotlight every day — curated videos, free reading, tips and a 4-week plan to get you started in {cat?.name}.
                </p>
                <span className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-black transition group-hover:gap-3">
                  Start learning <ArrowRightIcon size={16} />
                </span>
              </div>
            </Link>
          </Tilt>
        </Reveal>

        <Reveal delay={100}>
          <div className="card h-full rounded-3xl p-5 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-brand">Fresh from the web</p>
                <h2 className="font-display mt-1 text-xl font-bold">Trending for beginners this week</h2>
              </div>
              <Pill tone="good">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-good" /> Live
              </Pill>
            </div>
            <ul className="mt-4 divide-y divide-line">
              {trending.status === "loading" &&
                Array.from({ length: 5 }, (_, i) => (
                  <li key={i} className="flex gap-3 py-3">
                    <div className="skeleton h-14 w-20 shrink-0 rounded-lg" />
                    <div className="flex-1 space-y-2 pt-1">
                      <div className="skeleton h-3.5 w-11/12 rounded" />
                      <div className="skeleton h-3 w-1/2 rounded" />
                    </div>
                  </li>
                ))}
              {trending.data?.slice(0, 5).map((a) => (
                <li key={a.id}>
                  <a href={a.url} target="_blank" rel="noopener noreferrer" className="group flex gap-3 py-3">
                    <div className="h-14 w-20 shrink-0 overflow-hidden rounded-lg bg-surface2">
                      <SafeImage src={a.thumb} alt="" className="h-full w-full object-cover" fallback={<div className="grid h-full w-full place-items-center text-xl">📰</div>} />
                    </div>
                    <div className="min-w-0">
                      <p className="prose-clamp-2 text-sm font-semibold leading-snug transition group-hover:text-brand">{a.title}</p>
                      <p className="mt-1 truncate text-xs text-muted">{a.meta}</p>
                    </div>
                  </a>
                </li>
              ))}
              {trending.status === "error" && !trending.data && (
                <li className="py-6 text-center text-sm text-muted">
                  Couldn't load the live feed right now.{" "}
                  <a className="font-semibold text-brand hover:underline" href="https://dev.to/t/beginners" target="_blank" rel="noopener noreferrer">
                    Open it directly →
                  </a>
                </li>
              )}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Categories() {
  return (
    <section id="categories" className="mx-auto max-w-7xl px-4 pt-20 sm:px-6" aria-labelledby="cats-title">
      <Reveal>
        <SectionHeading id="cats-title" eyebrow="Explore" title="Pick a world to learn in" desc="Eight categories, dozens of skills, one tap away. Or just search for anything above." />
      </Reveal>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {categories.map((c, i) => (
          <Reveal key={c.id} delay={(i % 4) * 70}>
            <Tilt max={6} className="h-full">
              <div className="card flex h-full flex-col rounded-3xl p-5">
                <Link to={{ name: "category", id: c.id }} className="tilt-pop group">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl text-3xl shadow-lg" style={{ background: `linear-gradient(135deg, ${c.color}55, ${c.color}18)`, boxShadow: `0 10px 30px -12px ${c.color}` }}>
                    {c.emoji}
                  </span>
                  <h3 className="font-display mt-4 text-lg font-bold group-hover:text-brand">{c.name}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{c.blurb}</p>
                </Link>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {topicsIn(c.id).slice(0, 4).map((t) => (
                    <Link key={t.name} to={searchRoute(t.name)} className="chip rounded-full px-2.5 py-1 text-xs font-medium">
                      {t.name}
                    </Link>
                  ))}
                </div>
                <Link to={{ name: "category", id: c.id }} className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-semibold text-brand hover:gap-2.5">
                  All {topicsIn(c.id).length} skills <ArrowRightIcon size={15} />
                </Link>
              </div>
            </Tilt>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Featured() {
  const items = FEATURED.map((n) => topics.find((t) => t.name === n)).filter((t): t is NonNullable<typeof t> => !!t);
  return (
    <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6" aria-labelledby="feat-title">
      <Reveal>
        <SectionHeading id="feat-title" eyebrow="Popular right now" title="Skills people are learning" desc="Tap a card to open its full learning page: videos, reading, free courses, tips and plan." />
      </Reveal>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
        {items.map((t, i) => (
          <Reveal key={t.name} delay={(i % 4) * 60}>
            <TopicCard topic={t} />
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { n: "01", icon: "🔎", title: "Search any skill", text: "Type anything you want to learn. Suggestions appear as you type, from our catalog and the web." },
    { n: "02", icon: "🧭", title: "Get everything in one place", text: "Verified YouTube videos, articles, free books and courses, practical tips and a 4-week plan — organised and ready." },
    { n: "03", icon: "🚀", title: "Learn and track progress", text: "Save favourites to your learning list, tick off roadmap steps, and come back anytime. It all stays on your device." },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6" aria-labelledby="how-title">
      <Reveal>
        <SectionHeading id="how-title" eyebrow="How it works" title="From “I want to learn…” to learning in three steps" />
      </Reveal>
      <div className="grid gap-4 md:grid-cols-3">
        {steps.map((s, i) => (
          <Reveal key={s.n} delay={i * 90}>
            <Tilt max={7} className="h-full">
              <div className="card relative h-full overflow-hidden rounded-3xl p-6">
                <span className="font-display absolute -right-2 -top-4 text-8xl font-extrabold text-ink/[0.045]">{s.n}</span>
                <span className="tilt-pop grid h-14 w-14 place-items-center rounded-2xl bg-brand/12 text-3xl">{s.icon}</span>
                <h3 className="font-display mt-5 text-lg font-bold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{s.text}</p>
              </div>
            </Tilt>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function LinkGuardCard() {
  const checks = [
    ["Live from the source", "Results are fetched the moment you search, so links point at what exists today."],
    ["Embed-checked videos", "Catalog videos are verified with YouTube to confirm they exist and can be played."],
    ["Dead thumbnails vanish", "If a video's thumbnail fails to load, that card is hidden automatically."],
    ["Piracy filter", "Cracks, keygens, torrents and re-uploaded paid courses never make it onto a page."],
    ["Always-works fallbacks", "Every section ends with a direct link to a search page on the original platform."],
  ];
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {checks.map(([t, d]) => (
        <li key={t} className="flex gap-3 rounded-2xl border border-line bg-surface/70 p-4">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-good/15 text-good">
            <ShieldIcon size={18} />
          </span>
          <div>
            <p className="text-sm font-semibold">{t}</p>
            <p className="mt-0.5 text-xs leading-relaxed text-muted">{d}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}

function LinkGuard() {
  const stats = catalogStats();
  return (
    <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6" aria-labelledby="guard-title">
      <Reveal>
        <div className="relative overflow-hidden rounded-[2rem] border border-line bg-[linear-gradient(135deg,color-mix(in_oklab,var(--good)_9%,var(--surface)),var(--surface))] p-6 sm:p-10">
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div>
              <Pill tone="good" className="px-3 py-1 text-xs">
                <ShieldIcon size={13} /> Link Guard
              </Pill>
              <h2 id="guard-title" className="font-display mt-4 text-2xl font-extrabold tracking-tight sm:text-4xl">
                No broken links. No cracked content. <span className="text-gradient">No irritation.</span>
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-muted sm:text-base">
                Nothing is more annoying than clicking a dead link. {SITE.name} is built so that doesn't happen — and so you only ever land on legitimate, free learning material.
              </p>
              <dl className="mt-6 grid max-w-md grid-cols-3 gap-3 text-center">
                {[
                  [stats.topics + "+", "skills"],
                  [stats.videos + "", "verified videos"],
                  ["6", "live sources"],
                ].map(([n, l]) => (
                  <div key={l} className="rounded-2xl border border-line bg-surface/70 p-3">
                    <dt className="font-display text-2xl font-extrabold text-gradient">{n}</dt>
                    <dd className="text-[11px] text-muted">{l}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <LinkGuardCard />
          </div>
        </div>
      </Reveal>
    </section>
  );
}

function FAQSection() {
  return (
    <section className="mx-auto max-w-3xl px-4 pt-20 sm:px-6" aria-labelledby="faq-title">
      <Reveal>
        <SectionHeading id="faq-title" eyebrow="FAQ" title="Questions, answered" />
      </Reveal>
      <div className="space-y-3">
        {FAQ.map((f) => (
          <Reveal key={f.q}>
            <details className="card group rounded-2xl px-5 py-4 open:border-brand/50">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold sm:text-base [&::-webkit-details-marker]:hidden">
                {f.q}
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-surface2 text-lg leading-none transition group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-muted">{f.a}</p>
            </details>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-4 pt-20 sm:px-6" aria-label="Start learning">
      <Reveal>
        <div className="relative isolate overflow-hidden rounded-[2rem] border border-line p-8 text-center sm:p-14">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,color-mix(in_oklab,var(--brand)_28%,transparent),transparent_70%),radial-gradient(ellipse_at_bottom_right,color-mix(in_oklab,var(--brand-2)_22%,transparent),transparent_60%)]" />
          <h2 className="font-display text-3xl font-extrabold tracking-tight sm:text-5xl">What will you learn today?</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted sm:text-base">One search away from your next skill. It's free, it's fast, and it never goes stale.</p>
          <div className="mx-auto mt-8 max-w-2xl text-left">
            <SearchBox size="lg" />
          </div>
        </div>
      </Reveal>
    </section>
  );
}

export default function Home() {
  const faqLd = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: FAQ.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
    }),
    []
  );
  useSEO({
    title: `${SITE.name} — Learn Any Skill Free: Videos, Courses, Books & Tips`,
    description: SITE.description,
    search: "",
    image: absUrl("og-image.png"),
    jsonLd: [faqLd],
  });

  return (
    <>
      <Hero />
      <Marquee />
      <Today />
      <Categories />
      <Featured />
      <HowItWorks />
      <LinkGuard />
      <FAQSection />
      <CTA />
    </>
  );
}
