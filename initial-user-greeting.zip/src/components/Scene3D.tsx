import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import type { Category } from "@/lib/types";

/**
 * Interactive 3D hero.
 *  - A living, noise-displaced orb (GLSL shader) that surges when you type in the search box.
 *  - One planet per category orbiting it. Hover = label, click = jump to that category.
 *  - Drag (or swipe sideways) to spin the whole system. Mouse parallax. Pauses off-screen.
 *  - Falls back to a CSS orb if WebGL isn't available.
 */

const NOISE = /* glsl */ `
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}`;

const VERT = /* glsl */ `
uniform float uTime; uniform float uEnergy;
varying vec3 vNormal; varying vec3 vView; varying float vNoise;
${NOISE}
void main(){
  vec3 n = normalize(position);
  float a = snoise(n*1.35 + vec3(uTime*0.25));
  float b = snoise(n*3.1 - vec3(uTime*0.45));
  float d = (a*0.24 + b*0.075) * (1.0 + uEnergy*1.7);
  vec3 p = position + normal*d;
  vNoise = d;
  vNormal = normalize(normalMatrix*normal);
  vec4 mv = modelViewMatrix*vec4(p,1.0);
  vView = normalize(-mv.xyz);
  gl_Position = projectionMatrix*mv;
}`;

const FRAG = /* glsl */ `
uniform vec3 uA; uniform vec3 uB; uniform vec3 uC; uniform float uEnergy;
varying vec3 vNormal; varying vec3 vView; varying float vNoise;
void main(){
  vec3 N = normalize(vNormal); vec3 V = normalize(vView);
  float fres = pow(1.0 - max(dot(N,V),0.0), 2.4);
  float t = smoothstep(-0.28, 0.32, vNoise);
  vec3 col = mix(uA, uB, t);
  col = mix(col, uC, fres*0.95);
  vec3 L = normalize(vec3(0.5,0.8,1.0));
  float spec = pow(max(dot(reflect(-L,N),V),0.0), 26.0);
  float diff = max(dot(N,L),0.0)*0.35;
  col += spec*0.55 + fres*0.32 + diff*0.25 + uEnergy*0.12;
  gl_FragColor = vec4(col,1.0);
}`;

function glowTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  grad.addColorStop(0, "rgba(139,108,255,0.55)");
  grad.addColorStop(0.45, "rgba(34,211,238,0.16)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

interface Props {
  categories: Category[];
  onPick: (catId: string) => void;
}

export default function Scene3D({ categories, onPick }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const tipRef = useRef<HTMLDivElement>(null);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch {
      setFailed(true);
      return;
    }
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    const canvas = renderer.domElement;
    canvas.style.cssText = "display:block;width:100%;height:100%;touch-action:pan-y;cursor:grab;outline:none";
    wrap.prepend(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    camera.position.set(0, 0, 11);

    scene.add(new THREE.AmbientLight(0xffffff, 0.8));
    const l1 = new THREE.PointLight(0x8b6cff, 260, 40);
    l1.position.set(6, 4, 6);
    const l2 = new THREE.PointLight(0x22d3ee, 200, 40);
    l2.position.set(-6, -3, 5);
    const l3 = new THREE.PointLight(0xf472b6, 140, 40);
    l3.position.set(0, 6, -4);
    scene.add(l1, l2, l3);

    const world = new THREE.Group();
    scene.add(world);

    /* Orb */
    const orbMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uEnergy: { value: 0 },
        uA: { value: new THREE.Color("#4f35e8") },
        uB: { value: new THREE.Color("#22d3ee") },
        uC: { value: new THREE.Color("#f472b6") },
      },
      vertexShader: VERT,
      fragmentShader: FRAG,
    });
    const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(1.7, 24), orbMat);
    world.add(orb);

    const shell = new THREE.Mesh(
      new THREE.IcosahedronGeometry(2.3, 2),
      new THREE.MeshBasicMaterial({ color: 0x9be8ff, wireframe: true, transparent: true, opacity: 0.14 })
    );
    world.add(shell);

    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({ map: glowTexture(), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.95 })
    );
    glow.scale.set(10, 10, 1);
    glow.position.z = -1.5;
    scene.add(glow);

    /* Star dust */
    const N = 650;
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const r = 5 + Math.random() * 8;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th);
      pos[i * 3 + 2] = r * Math.cos(ph);
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const dust = new THREE.Points(
      dustGeo,
      new THREE.PointsMaterial({ color: 0xb9b3ff, size: 0.05, transparent: true, opacity: 0.75, depthWrite: false })
    );
    world.add(dust);

    /* Category planets */
    const shapes: THREE.BufferGeometry[] = [
      new THREE.TorusKnotGeometry(0.26, 0.085, 80, 10),
      new THREE.OctahedronGeometry(0.38),
      new THREE.IcosahedronGeometry(0.38, 0),
      new THREE.BoxGeometry(0.5, 0.5, 0.5),
      new THREE.ConeGeometry(0.34, 0.72, 5),
      new THREE.TorusGeometry(0.3, 0.12, 12, 28),
      new THREE.DodecahedronGeometry(0.38),
      new THREE.TetrahedronGeometry(0.46),
    ];
    const sats = categories.map((cat, i) => {
      const tilt = new THREE.Group();
      tilt.rotation.set(Math.sin(i * 2.1) * 0.55, 0, Math.cos(i * 1.7) * 0.5);
      const spin = new THREE.Group();
      spin.rotation.y = (i / categories.length) * Math.PI * 2;
      const radius = 3.25 + (i % 4) * 0.5;
      const mesh = new THREE.Mesh(
        shapes[i % shapes.length],
        new THREE.MeshStandardMaterial({
          color: cat.color,
          emissive: cat.color,
          emissiveIntensity: 0.5,
          metalness: 0.3,
          roughness: 0.3,
        })
      );
      mesh.position.set(radius, 0, 0);
      mesh.userData = { index: i };
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(radius - 0.007, radius + 0.007, 160),
        new THREE.MeshBasicMaterial({ color: cat.color, transparent: true, opacity: 0.2, side: THREE.DoubleSide })
      );
      ring.rotation.x = Math.PI / 2;
      spin.add(mesh);
      tilt.add(ring, spin);
      world.add(tilt);
      return { cat, mesh, spin, speed: (0.22 + ((i * 7) % 5) * 0.045) * (i % 2 ? -1 : 1), scale: 1 };
    });
    const satMeshes = sats.map((s) => s.mesh);

    /* Interaction state */
    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2(0, 0);
    let inside = false;
    let dragging = false;
    let moved = 0;
    let lastX = 0;
    let lastY = 0;
    const rot = { x: 0.12, y: 0 };
    const vel = { x: 0, y: 0 };
    const AUTO = reduce ? 0.0006 : 0.0016;
    vel.y = AUTO;
    let hovered = -1;
    let energy = 0;
    let visible = true;
    let raf = 0;
    let last = performance.now();
    const v3 = new THREE.Vector3();

    const setNdc = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    };
    const hit = (): number => {
      raycaster.setFromCamera(ndc, camera);
      const h = raycaster.intersectObjects(satMeshes, false)[0];
      return h ? (h.object.userData.index as number) : -1;
    };
    const onMove = (e: PointerEvent) => {
      setNdc(e);
      inside = true;
      if (dragging) {
        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;
        moved += Math.abs(dx) + Math.abs(dy);
        lastX = e.clientX;
        lastY = e.clientY;
        vel.y = dx * 0.0035;
        vel.x = dy * 0.002;
        rot.y += dx * 0.0055;
        rot.x = THREE.MathUtils.clamp(rot.x + dy * 0.004, -0.7, 0.7);
      }
    };
    const onDown = (e: PointerEvent) => {
      setNdc(e);
      dragging = true;
      moved = 0;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.style.cursor = "grabbing";
      try {
        canvas.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    };
    const onUp = (e: PointerEvent) => {
      dragging = false;
      canvas.style.cursor = hovered >= 0 ? "pointer" : "grab";
      setNdc(e);
      if (moved < 7) {
        const i = hit();
        if (i >= 0) pickRef.current(sats[i].cat.id);
        else {
          raycaster.setFromCamera(ndc, camera);
          if (raycaster.intersectObject(orb, false).length) energy = 1.1;
        }
      }
    };
    const onLeave = () => {
      inside = false;
      dragging = false;
      hovered = -1;
      if (tipRef.current) tipRef.current.style.opacity = "0";
    };
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onLeave);
    canvas.addEventListener("pointerleave", onLeave);

    const onEnergy = () => {
      energy = Math.min(1.2, energy + 0.55);
    };
    window.addEventListener("lo:energy", onEnergy);

    /* Sizing */
    const resize = () => {
      const w = wrap.clientWidth || 1;
      const h = wrap.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.position.z = camera.aspect < 0.9 ? 16 : 14;
      camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    resize();

    /* Render loop */
    let time = 0;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const speed = reduce ? 0.25 : 1;
      time += dt * (0.6 + energy * 1.4) * speed;
      orbMat.uniforms.uTime.value = time;
      orbMat.uniforms.uEnergy.value = energy;
      orb.scale.setScalar(1 + energy * 0.07);
      energy *= Math.exp(-dt * 2.2);

      if (!dragging) {
        vel.x *= 0.94;
        vel.y += (AUTO - vel.y) * 0.025;
        rot.y += vel.y;
        rot.x += vel.x;
        const targetX = 0.12 + (inside ? ndc.y * 0.18 : 0);
        rot.x += (targetX - rot.x) * 0.04;
      }
      world.rotation.set(rot.x, rot.y, 0);
      shell.rotation.y -= dt * 0.15 * speed;
      shell.rotation.x += dt * 0.07 * speed;
      dust.rotation.y += dt * 0.012 * speed;
      camera.position.x += ((inside ? ndc.x * 0.7 : 0) - camera.position.x) * 0.04;
      camera.lookAt(0, 0, 0);
      glow.material.opacity = 0.8 + energy * 0.2;

      sats.forEach((s, i) => {
        s.spin.rotation.y += dt * s.speed * speed;
        s.mesh.rotation.x += dt * 0.7 * speed;
        s.mesh.rotation.y += dt * 0.5 * speed;
        const target = i === hovered ? 1.6 : 1;
        s.scale += (target - s.scale) * 0.15;
        s.mesh.scale.setScalar(s.scale);
        (s.mesh.material as THREE.MeshStandardMaterial).emissiveIntensity = i === hovered ? 1.1 : 0.5;
      });

      // hover detection + tooltip
      if (inside && !dragging) {
        const i = hit();
        if (i !== hovered) {
          hovered = i;
          canvas.style.cursor = i >= 0 ? "pointer" : "grab";
        }
      }
      const tip = tipRef.current;
      if (tip) {
        if (hovered >= 0) {
          sats[hovered].mesh.getWorldPosition(v3);
          v3.project(camera);
          const w = wrap.clientWidth;
          const h = wrap.clientHeight;
          tip.textContent = `${sats[hovered].cat.emoji}  ${sats[hovered].cat.name}`;
          tip.style.transform = `translate(${(v3.x * 0.5 + 0.5) * w}px, ${(-v3.y * 0.5 + 0.5) * h}px) translate(-50%, -190%)`;
          tip.style.opacity = "1";
        } else {
          tip.style.opacity = "0";
        }
      }
      renderer.render(scene, camera);
    };

    const start = () => {
      if (!raf && visible) {
        last = performance.now();
        raf = requestAnimationFrame(frame);
      }
    };
    const stop = () => {
      cancelAnimationFrame(raf);
      raf = 0;
    };
    const io = new IntersectionObserver(
      (entries) => {
        visible = entries.some((e) => e.isIntersecting);
        if (visible) start();
        else stop();
      },
      { threshold: 0.01 }
    );
    io.observe(wrap);
    start();

    return () => {
      stop();
      io.disconnect();
      ro.disconnect();
      window.removeEventListener("lo:energy", onEnergy);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onLeave);
      canvas.removeEventListener("pointerleave", onLeave);
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        m.geometry?.dispose?.();
        const mat = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else if (mat) {
          (mat as THREE.SpriteMaterial).map?.dispose?.();
          mat.dispose();
        }
      });
      renderer.dispose();
      renderer.forceContextLoss();
      canvas.remove();
    };
  }, [categories]);

  if (failed) {
    return (
      <div className="relative grid h-full w-full place-items-center" aria-hidden="true">
        <div className="h-56 w-56 animate-float rounded-full bg-[radial-gradient(circle_at_30%_30%,var(--accent),var(--brand)_50%,var(--brand-2))] shadow-[0_0_90px_var(--glow)]" />
      </div>
    );
  }

  return (
    <div ref={wrapRef} className="relative h-full w-full select-none" role="img" aria-label="Interactive 3D model: skill categories orbiting a glowing sphere. Drag to rotate, click a planet to explore it.">
      <div
        ref={tipRef}
        className="pointer-events-none absolute left-0 top-0 z-10 whitespace-nowrap rounded-full border border-line bg-surface/90 px-3 py-1 text-xs font-semibold opacity-0 shadow-lg backdrop-blur transition-opacity duration-150"
      />
    </div>
  );
}
