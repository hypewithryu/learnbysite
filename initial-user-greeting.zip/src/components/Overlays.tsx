import { useEffect, useState } from "react";
import { clearSaved, removeSaved, useSaved } from "@/lib/store";
import { copyText, toast, type ToastDetail } from "@/lib/toast";
import { SITE } from "@/lib/config";
import { CheckIcon, CopyIcon, ExternalIcon, RefreshIcon, SparkleIcon, TrashIcon, XIcon } from "./Icons";
import { SafeImage } from "./Ui";

/* ───────── Toasts ───────── */
export function Toaster() {
  const [items, setItems] = useState<Array<ToastDetail & { id: number }>>([]);
  useEffect(() => {
    let n = 0;
    const on = (e: Event) => {
      const d = (e as CustomEvent<ToastDetail>).detail;
      const id = ++n;
      setItems((cur) => [...cur.slice(-2), { ...d, id }]);
      setTimeout(() => setItems((cur) => cur.filter((t) => t.id !== id)), 2600);
    };
    window.addEventListener("lo:toast", on);
    return () => window.removeEventListener("lo:toast", on);
  }, []);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-5 z-[90] flex flex-col items-center gap-2 px-4" aria-live="polite">
      {items.map((t) => (
        <div key={t.id} className="animate-pop-in pointer-events-auto flex items-center gap-2 rounded-full border border-line bg-surface px-4 py-2.5 text-sm font-medium shadow-xl shadow-black/30">
          <span className="grid h-5 w-5 place-items-center rounded-full bg-good/20 text-good">
            <CheckIcon size={12} />
          </span>
          {t.message}
        </div>
      ))}
    </div>
  );
}

/* ───────── "New version" banner (the site updates itself) ───────── */
export function UpdateBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(true);
    window.addEventListener("lo:update", on);
    if (window.__loUpdateReady) setShow(true);
    return () => window.removeEventListener("lo:update", on);
  }, []);
  if (!show) return null;
  return (
    <div className="animate-pop-in fixed bottom-5 left-1/2 z-[80] flex w-[min(94vw,460px)] -translate-x-1/2 items-center gap-3 rounded-2xl border border-brand/40 bg-surface p-3 pl-4 shadow-2xl shadow-black/40" role="status">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-brand/15 text-brand">
        <SparkleIcon size={18} />
      </span>
      <p className="flex-1 text-sm leading-snug">
        <strong className="font-semibold">A fresh version of {SITE.name} is ready.</strong>
        <span className="block text-xs text-muted">It will apply automatically on your next search.</span>
      </p>
      <button type="button" onClick={() => window.location.reload()} className="btn-primary h-9 shrink-0 rounded-xl px-3.5 text-sm">
        <RefreshIcon size={15} /> Update
      </button>
      <button type="button" onClick={() => setShow(false)} aria-label="Dismiss" className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted hover:bg-surface2">
        <XIcon size={15} />
      </button>
    </div>
  );
}

/* ───────── Saved list drawer ───────── */
export function SavedDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const saved = useSaved();

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;

  const copyAll = async () => {
    const text = saved.map((i) => `${i.title}\n${i.url}`).join("\n\n");
    toast((await copyText(text)) ? "All links copied" : "Couldn't copy – select and copy manually");
  };

  return (
    <div className="animate-fade-in fixed inset-0 z-[75] bg-black/60 backdrop-blur-sm" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="animate-slide-in absolute right-0 top-0 flex h-full w-[min(100vw,420px)] flex-col border-l border-line bg-surface shadow-2xl" role="dialog" aria-modal="true" aria-label="My learning list">
        <div className="flex items-center justify-between border-b border-line p-4">
          <div>
            <h2 className="font-display text-lg font-bold">My learning list</h2>
            <p className="text-xs text-muted">Saved on this device · {saved.length} item{saved.length === 1 ? "" : "s"}</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full hover:bg-surface2">
            <XIcon size={18} />
          </button>
        </div>

        <div className="flex-1 space-y-2.5 overflow-y-auto p-4">
          {saved.length === 0 ? (
            <div className="grid h-full place-items-center text-center">
              <div className="max-w-[260px]">
                <div className="mb-3 text-5xl">🔖</div>
                <p className="font-semibold">Nothing saved yet</p>
                <p className="mt-1 text-sm text-muted">Tap the bookmark on any video, article or course to keep it here for later.</p>
              </div>
            </div>
          ) : (
            saved.map((it) => (
              <div key={it.id} className="card group flex gap-3 rounded-2xl p-2.5">
                <a href={it.url} target="_blank" rel="noopener noreferrer" className="flex min-w-0 flex-1 gap-3">
                  <div className="h-16 w-24 shrink-0 overflow-hidden rounded-xl bg-surface2">
                    <SafeImage src={it.thumb} alt="" className="h-full w-full object-cover" fallback={<div className="grid h-full w-full place-items-center text-2xl">{it.kind === "video" ? "▶️" : it.kind === "book" ? "📖" : "📄"}</div>} />
                  </div>
                  <div className="min-w-0 py-0.5">
                    <p className="prose-clamp-2 text-sm font-semibold leading-snug">{it.title}</p>
                    <p className="mt-1 flex items-center gap-1 truncate text-xs text-muted">
                      {it.source} <ExternalIcon size={11} />
                    </p>
                  </div>
                </a>
                <button type="button" onClick={() => removeSaved(it.id)} aria-label={`Remove ${it.title}`} className="grid h-8 w-8 shrink-0 place-items-center self-center rounded-full text-muted transition hover:bg-red-500/10 hover:text-red-500">
                  <TrashIcon size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {saved.length > 0 && (
          <div className="grid grid-cols-2 gap-2 border-t border-line p-4">
            <button type="button" onClick={copyAll} className="btn-ghost h-11 rounded-xl text-sm">
              <CopyIcon size={16} /> Copy all links
            </button>
            <button type="button" onClick={clearSaved} className="btn-ghost h-11 rounded-xl text-sm hover:!border-red-500/60 hover:!text-red-500">
              <TrashIcon size={16} /> Clear all
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
