import { useEffect, useRef } from "react";
import { ytWatch } from "@/lib/text";
import type { Video } from "@/lib/types";
import { ExternalIcon, XIcon } from "./Icons";
import { SaveButton } from "./Ui";
import { ytThumb } from "@/lib/text";

/** In-page YouTube player (privacy-friendly nocookie domain) with an always-visible "open on YouTube" fallback. */
export function VideoModal({ video, onClose }: { video: Video; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const prevFocus = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKey);
      prevFocus?.focus?.();
    };
  }, [onClose]);

  return (
    <div
      className="animate-fade-in fixed inset-0 z-[70] grid place-items-center bg-black/80 p-3 backdrop-blur-sm sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={video.title}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="animate-pop-in w-full max-w-4xl overflow-hidden rounded-3xl border border-line bg-surface shadow-2xl">
        <div className="relative aspect-video w-full bg-black">
          <iframe
            className="absolute inset-0 h-full w-full"
            src={`https://www.youtube-nocookie.com/embed/${video.id}?autoplay=1&rel=0&modestbranding=1&playsinline=1`}
            title={video.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
        </div>
        <div className="flex flex-wrap items-center gap-3 p-4 sm:p-5">
          <div className="min-w-0 flex-1">
            <h3 className="prose-clamp-2 font-display text-base font-semibold sm:text-lg">{video.title}</h3>
            <p className="mt-0.5 text-sm text-muted">
              {video.channel}
              {video.views ? ` · ${video.views} views` : ""}
            </p>
          </div>
          <SaveButton item={{ id: "yt:" + video.id, title: video.title, url: ytWatch(video.id), kind: "video", source: video.channel, thumb: ytThumb(video.id, "mq") }} />
          <a
            href={ytWatch(video.id)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost h-10 rounded-xl px-4 text-sm"
          >
            Open on YouTube <ExternalIcon size={15} />
          </a>
          <button ref={closeRef} type="button" onClick={onClose} className="btn-primary h-10 rounded-xl px-4 text-sm" aria-label="Close video">
            <XIcon size={16} /> Close
          </button>
        </div>
        <p className="border-t border-line px-5 py-3 text-xs text-muted">
          Video not playing? Some creators disable embedding in certain regions — the “Open on YouTube” button always works.
        </p>
      </div>
    </div>
  );
}
