import { useEffect, useRef, useState, type CSSProperties, type MouseEvent, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { toggleSaved, useSaved } from "@/lib/store";
import { toast } from "@/lib/toast";
import type { SavedItem } from "@/lib/types";
import { BookmarkIcon } from "./Icons";

/* ───────── 3D tilt wrapper (follows the cursor, adds a glare) ───────── */
const canTilt = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(hover: hover) and (pointer: fine)").matches &&
  !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export function Tilt({
  children,
  className,
  max = 8,
}: {
  children: ReactNode;
  className?: string;
  max?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el || !canTilt()) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.classList.remove("resting");
    el.style.setProperty("--ry", `${(px - 0.5) * max * 2}deg`);
    el.style.setProperty("--rx", `${-(py - 0.5) * max * 2}deg`);
    el.style.setProperty("--gx", `${px * 100}%`);
    el.style.setProperty("--gy", `${py * 100}%`);
  };
  const leave = () => {
    const el = ref.current;
    if (!el) return;
    el.classList.add("resting");
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };
  return (
    <div ref={ref} onMouseMove={move} onMouseLeave={leave} className={cn("tilt relative", className)}>
      {children}
      <span className="glare" />
    </div>
  );
}

/* ───────── Reveal on scroll ───────── */
export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "li";
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.05 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const style: CSSProperties = delay ? { transitionDelay: `${delay}ms` } : {};
  const Comp = Tag as "div";
  return (
    <Comp ref={ref} style={style} className={cn("reveal", shown && "in", className)}>
      {children}
    </Comp>
  );
}

/* ───────── Loaders ───────── */
export function CubeLoader({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center gap-4 py-10" role="status" aria-live="polite">
      <div className="cube-scene">
        <div className="cube">
          <i />
          <i />
          <i />
          <i />
          <i />
          <i />
        </div>
      </div>
      {label && <p className="text-sm text-muted">{label}</p>}
    </div>
  );
}

export function SkeletonGrid({ count = 6, aspect = "aspect-video" }: { count?: number; aspect?: string }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="card overflow-hidden rounded-2xl">
          <div className={cn("skeleton", aspect)} />
          <div className="space-y-2 p-4">
            <div className="skeleton h-4 w-11/12 rounded" />
            <div className="skeleton h-3 w-2/3 rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ───────── Small bits ───────── */
export function Pill({ children, tone = "neutral", className }: { children: ReactNode; tone?: "neutral" | "good" | "brand" | "warn"; className?: string }) {
  const tones = {
    neutral: "bg-surface2 text-muted border-line",
    good: "bg-good/12 text-good border-good/30",
    brand: "bg-brand/12 text-brand border-brand/30",
    warn: "bg-amber-400/12 text-amber-500 border-amber-400/30",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold", tones[tone], className)}>
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  desc,
  action,
  id,
}: {
  eyebrow?: string;
  title: ReactNode;
  desc?: ReactNode;
  action?: ReactNode;
  id?: string;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && <p className="mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-brand">{eyebrow}</p>}
        <h2 id={id} className="font-display text-xl font-bold tracking-tight sm:text-2xl">
          {title}
        </h2>
        {desc && <p className="mt-1 max-w-2xl text-sm text-muted">{desc}</p>}
      </div>
      {action}
    </div>
  );
}

export function SaveButton({ item, className }: { item: Omit<SavedItem, "savedAt">; className?: string }) {
  const saved = useSaved().some((i) => i.id === item.id);
  return (
    <button
      type="button"
      aria-pressed={saved}
      aria-label={saved ? "Remove from my learning list" : "Save to my learning list"}
      title={saved ? "Saved — click to remove" : "Save for later"}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        const added = toggleSaved(item);
        toast(added ? "Saved to your learning list" : "Removed from your list", added ? "ok" : "info");
      }}
      className={cn(
        "grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line bg-surface/80 backdrop-blur transition hover:border-brand hover:text-brand",
        saved && "border-brand bg-brand/15 text-brand",
        className
      )}
    >
      <BookmarkIcon size={17} filled={saved} />
    </button>
  );
}

/** <img> that gracefully swaps to a gradient placeholder if it fails to load. */
export function SafeImage({
  src,
  alt,
  className,
  fallback,
  onFail,
}: {
  src?: string;
  alt: string;
  className?: string;
  fallback: ReactNode;
  onFail?: () => void;
}) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  if (!src || failed) return <>{fallback}</>;
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      className={className}
      onError={() => {
        setFailed(true);
        onFail?.();
      }}
    />
  );
}
