import { SITE } from "@/lib/config";
import { Link, searchRoute } from "@/lib/router";
import { categories, topics } from "@/lib/topics";
import { LogoMark } from "./Logo";

const FEATURED = ["Python", "JavaScript", "Machine Learning", "Guitar", "Piano", "Spanish", "Japanese", "Photoshop", "Video Editing", "Yoga", "Investing", "Cooking", "Chess", "Public Speaking", "Mathematics", "Digital Marketing"];

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative mt-24 border-t border-line bg-surface/40" role="contentinfo">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1.4fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <LogoMark size={36} />
            <span className="font-display text-xl font-bold">{SITE.name}</span>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            {SITE.description}
          </p>
          <p className="mt-4 text-xs text-muted">
            Press <kbd className="rounded border border-line bg-surface2 px-1.5 py-0.5 font-mono text-[11px]">/</kbd> anywhere to search.
          </p>
        </div>

        <nav aria-label="Categories">
          <h3 className="mb-3 text-sm font-semibold">Categories</h3>
          <ul className="space-y-2 text-sm text-muted">
            {categories.map((c) => (
              <li key={c.id}>
                <Link to={{ name: "category", id: c.id }} className="transition hover:text-ink">
                  <span className="mr-2">{c.emoji}</span>
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Popular skills">
          <h3 className="mb-3 text-sm font-semibold">Popular skills</h3>
          <ul className="flex flex-wrap gap-2">
            {FEATURED.map((name) => {
              const t = topics.find((x) => x.name === name);
              return (
                <li key={name}>
                  <Link to={searchRoute(name)} className="chip rounded-full px-3 py-1.5 text-xs font-medium">
                    {t?.emoji} {name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs leading-relaxed text-muted sm:px-6 md:flex-row md:items-center md:justify-between">
          <p>
            © {year} {SITE.owner}. Results come live from Wikipedia, Wikiversity, Wikibooks, Open Library, DEV Community and YouTube. Videos and articles belong to their creators.
          </p>
          <p>We only link to free, legal learning resources — never cracked software or pirated content.</p>
        </div>
      </div>
    </footer>
  );
}
