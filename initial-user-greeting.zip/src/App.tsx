import { lazy, Suspense, useCallback, useEffect, useState } from "react";
import { Footer } from "./components/Footer";
import { Header } from "./components/Header";
import { SavedDrawer, Toaster, UpdateBanner } from "./components/Overlays";
import { CubeLoader } from "./components/Ui";
import { useRoute } from "./lib/router";
import Home from "./components/Home";

const Results = lazy(() => import("./components/Results"));
const CategoryPage = lazy(() => import("./components/CategoryPage"));

export default function App() {
  const route = useRoute();
  const [savedOpen, setSavedOpen] = useState(false);
  const closeSaved = useCallback(() => setSavedOpen(false), []);

  // Move keyboard focus to the main region on page changes (screen-reader friendly)
  const routeKey = route.name === "search" ? `s:${route.q}` : route.name === "category" ? `c:${route.id}` : "home";
  useEffect(() => {
    document.getElementById("main")?.focus({ preventScroll: true });
  }, [routeKey]);

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only z-[100] rounded-lg bg-brand px-4 py-2 font-semibold text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Header route={route} onOpenSaved={() => setSavedOpen(true)} />

      <main id="main" tabIndex={-1} className="flex-1 outline-none">
        {route.name === "home" && <Home />}
        {route.name === "search" && (
          <Suspense fallback={<CubeLoader label="Loading…" />}>
            <Results key={route.q.toLowerCase()} q={route.q} tab={route.tab} />
          </Suspense>
        )}
        {route.name === "category" && (
          <Suspense fallback={<CubeLoader label="Loading…" />}>
            <CategoryPage id={route.id} />
          </Suspense>
        )}
      </main>

      <Footer />
      <SavedDrawer open={savedOpen} onClose={closeSaved} />
      <UpdateBanner />
      <Toaster />
    </div>
  );
}
