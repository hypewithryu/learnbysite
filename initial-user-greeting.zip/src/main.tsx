import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { applyTheme } from "./lib/store";
import { captureBaseline, registerServiceWorker, startUpdater } from "./lib/updater";

// Fingerprint the running build *before* anything else touches the DOM (used by the self-updater).
captureBaseline();
applyTheme();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

startUpdater();
registerServiceWorker();
