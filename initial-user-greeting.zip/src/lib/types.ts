export interface Category {
  id: string;
  name: string;
  emoji: string;
  color: string;
  blurb: string;
}

export interface Topic {
  name: string;
  cat: string;
  emoji: string;
  aliases: string[];
  tag?: string;
  yt?: string;
  /** exact Wikipedia article to use for the overview (avoids "Spanish" -> "Spain") */
  wiki?: string;
}

export interface Video {
  id: string;
  title: string;
  channel: string;
  duration?: string;
  views?: string;
  published?: string;
  /** verified = checked with YouTube oEmbed (exists + embeddable) */
  origin: "verified" | "live";
}

export type ResourceKind = "article" | "course" | "book" | "lecture" | "wiki";

export interface Resource {
  id: string;
  title: string;
  desc?: string;
  url: string;
  thumb?: string;
  source: string;
  kind: ResourceKind;
  meta?: string;
  badge?: string;
}

export interface Overview {
  title: string;
  extract: string;
  thumb?: string;
  url: string;
}

export interface SavedItem {
  id: string;
  title: string;
  url: string;
  kind: "video" | ResourceKind | "link";
  source: string;
  thumb?: string;
  savedAt: number;
}

export type Tab = "all" | "videos" | "read" | "learn" | "tips" | "links";

export type Route =
  | { name: "home" }
  | { name: "search"; q: string; tab: Tab }
  | { name: "category"; id: string };
