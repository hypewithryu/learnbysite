import cfg from "@/site.config.json";

export const SITE = {
  name: cfg.name,
  tagline: cfg.tagline,
  description: cfg.description,
  owner: cfg.owner,
  ownerUrl: cfg.ownerUrl,
  twitter: cfg.twitter,
  themeColor: cfg.themeColor,
  keywords: cfg.keywords,
  domain: cfg.domain.replace(/\/+$/, ""),
};

/** Optional: set VITE_YOUTUBE_API_KEY at build time for official YouTube Data API search. */
export const YT_API_KEY: string = (import.meta.env.VITE_YOUTUBE_API_KEY as string | undefined) || "";

/** Absolute URL of the site root (uses the configured domain, falls back to wherever it is hosted). */
export function siteRoot(): string {
  if (SITE.domain) return SITE.domain + "/";
  if (typeof location === "undefined") return "/";
  const path = location.pathname.replace(/[^/]*$/, "");
  return location.origin + path;
}

export function absUrl(search = ""): string {
  return siteRoot() + search;
}
