import data from "@/data/topics.json";
import videoData from "@/data/videos.json";
import type { Category, Topic, Video } from "./types";
import { cleanQuery, normalize, ytThumb } from "./text";

export const categories = data.categories as Category[];
export const topics = data.topics as Topic[];

const videoMap = (videoData as { topics: Record<string, Array<Omit<Video, "origin">>> }).topics;
export const catalogUpdatedAt: string | null = (videoData as { generatedAt: string | null }).generatedAt;

export const catById = (id: string | undefined): Category | undefined => categories.find((c) => c.id === id);
export const topicsIn = (catId: string): Topic[] => topics.filter((t) => t.cat === catId);

const index = topics.map((t) => ({
  topic: t,
  names: [t.name, ...t.aliases].map(normalize),
}));

export interface TopicMatch {
  topic: Topic;
  strength: "exact" | "partial";
}

/** Find the catalog topic that best matches whatever the visitor typed. */
export function matchTopic(raw: string): TopicMatch | null {
  const full = normalize(raw);
  const clean = normalize(cleanQuery(raw));
  if (!clean) return null;
  for (const { topic, names } of index) {
    if (names.includes(full) || names.includes(clean)) return { topic, strength: "exact" };
  }
  // partial: query contains a (long enough) topic name as whole words
  const padded = ` ${clean} `;
  let best: { topic: Topic; len: number } | null = null;
  for (const { topic, names } of index) {
    for (const n of names) {
      if (n.length > 3 && padded.includes(` ${n} `) && (!best || n.length > best.len)) {
        best = { topic, len: n.length };
      }
    }
  }
  return best ? { topic: best.topic, strength: "partial" } : null;
}

export function curatedVideos(topic: Topic | undefined): Video[] {
  if (!topic) return [];
  return (videoMap[topic.name] || []).map((v) => ({ ...v, origin: "verified" as const }));
}

export function topicThumb(topic: Topic): string | undefined {
  const v = videoMap[topic.name]?.[0];
  return v ? ytThumb(v.id, "mq") : undefined;
}

export function catalogStats() {
  const videoCount = Object.values(videoMap).reduce((n, a) => n + a.length, 0);
  return { topics: topics.length, categories: categories.length, videos: videoCount };
}

/** Deterministic "skill of the day" – changes by itself every day. */
export function skillOfTheDay(d = new Date()): Topic {
  const day = Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86_400_000);
  return topics[day % topics.length];
}

export function relatedTopics(topic: Topic | undefined, exclude: string, n = 8): Topic[] {
  if (!topic) return [];
  return topics.filter((t) => t.cat === topic.cat && t.name !== topic.name && t.name !== exclude).slice(0, n);
}

const CATEGORY_HINTS: Array<[string, RegExp]> = [
  ["music", /\b(guitar|piano|drum|song|music|sing|violin|bass|flute|saxophone|trumpet|dj|chord|melody|ukulele|vocal)/i],
  ["languages", /\b(language|speak|spanish|french|german|japanese|korean|chinese|arabic|italian|portuguese|russian|hindi|urdu|turkish|grammar|vocabulary|ielts|toefl)/i],
  ["tech", /\b(code|coding|program|developer|software|app|web|data|network|api|framework|algorithm|computer|ai|ml|cloud|devops|database|android|ios|game dev|unity|unreal|php|ruby|kotlin|swift|golang|node|vue|angular|css|html)/i],
  ["creative", /\b(design|draw|paint|photo|video|animation|art|illustrat|3d|film|edit|logo|sketch|craft|sew|knit|pottery)/i],
  ["business", /\b(business|market|invest|stock|trade|sales|money|finance|startup|freelanc|ecommerce|dropship|crypto|negotiat|leadership|management|accounting)/i],
  ["health", /\b(yoga|fitness|workout|exercise|health|diet|nutrition|run|swim|meditat|sleep|gym|stretch|martial|boxing|cycling)/i],
  ["science", /\b(math|physics|chemistry|biology|science|astronomy|statistics|calculus|geometry|algebra|engineering|geology|psychology)/i],
  ["life", /\b(cook|bak|chess|garden|write|writing|read|memory|focus|habit|time|parent|driv|travel|diy|repair|cleaning|organi[sz]e|public)/i],
];

/** Pick a category for any query – used to tailor tips and link suggestions. */
export function categoryFor(raw: string): Category | undefined {
  const m = matchTopic(raw);
  if (m) return catById(m.topic.cat);
  for (const [id, re] of CATEGORY_HINTS) if (re.test(raw)) return catById(id);
  return undefined;
}
