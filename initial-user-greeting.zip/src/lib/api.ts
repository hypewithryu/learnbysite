import { cached, HOUR } from "./cache";
import { YT_API_KEY } from "./config";
import { firstSuccess, getJSON } from "./net";
import { isSafe, safeUrl } from "./safety";
import { cleanQuery, formatSeconds, compactNumber, stripHtml, tagSlug, truncate } from "./text";
import type { Overview, Resource, Video } from "./types";

const enc = encodeURIComponent;

/* ───────────────────────── Wikipedia family (Wikipedia / Wikiversity / Wikibooks) ───────────────────────── */

interface WikiRaw {
  pageid: number;
  title: string;
  index?: number;
  extract?: string;
  fullurl?: string;
  thumbnail?: { source: string };
}

async function wikiPages(host: string, q: string, limit: number): Promise<WikiRaw[]> {
  const props = enc("extracts|pageimages|info");
  const url =
    `https://${host}/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${enc(q)}` +
    `&gsrlimit=${limit}&gsrnamespace=0&prop=${props}&exintro=1&explaintext=1&exsentences=3&exlimit=max` +
    `&piprop=thumbnail&pithumbsize=480&inprop=url`;
  const json = await getJSON<{ query?: { pages?: Record<string, WikiRaw> } }>(url);
  return Object.values(json.query?.pages ?? {}).sort((a, b) => (a.index ?? 99) - (b.index ?? 99));
}

const isDisambig = (p: WikiRaw) =>
  /\(disambiguation\)/i.test(p.title) || /\bmay (also )?refer to\b/i.test(p.extract || "");

function toResource(p: WikiRaw, source: string, kind: Resource["kind"]): Resource | null {
  const url = safeUrl(p.fullurl);
  if (!url || !isSafe(p.title, p.extract)) return null;
  return {
    id: `${source}:${p.pageid}`,
    title: p.title,
    desc: truncate(p.extract, 170),
    url,
    thumb: p.thumbnail?.source,
    source,
    kind,
  };
}

export interface WikiResult {
  overview: Overview | null;
  related: Resource[];
}

export function getWiki(q: string, force = false, hint?: string): Promise<WikiResult> {
  const query = hint || cleanQuery(q);
  return cached(
    `wiki:${query.toLowerCase()}`,
    6 * HOUR,
    async () => {
      const pages = (await wikiPages("en.wikipedia.org", query, 8)).filter((p) => !isDisambig(p));
      const first = pages[0];
      const overview: Overview | null =
        first && first.fullurl
          ? { title: first.title, extract: truncate(first.extract, 520), thumb: first.thumbnail?.source, url: first.fullurl }
          : null;
      const related = pages
        .slice(1)
        .map((p) => toResource(p, "Wikipedia", "wiki"))
        .filter((r): r is Resource => !!r);
      return { overview, related };
    },
    force
  );
}

export function getCourses(q: string, force = false): Promise<Resource[]> {
  const query = cleanQuery(q);
  return cached(
    `wikiversity:${query.toLowerCase()}`,
    12 * HOUR,
    async () =>
      (await wikiPages("en.wikiversity.org", query, 8))
        .filter((p) => !isDisambig(p))
        .map((p) => toResource(p, "Wikiversity", "course"))
        .filter((r): r is Resource => !!r),
    force
  );
}

/* ───────────────────────── Books ───────────────────────── */

interface OLDoc {
  key: string;
  title: string;
  author_name?: string[];
  first_publish_year?: number;
  cover_i?: number;
  ebook_access?: string;
}

async function openLibrary(q: string): Promise<Resource[]> {
  const term = q.replace(/["()]/g, " ");
  const query = `(title:(${term}) OR subject:(${term})) AND ebook_access:[borrowable TO *]`;
  const url =
    `https://openlibrary.org/search.json?q=${enc(query)}&sort=rating&limit=16` +
    `&fields=${enc("key,title,author_name,first_publish_year,cover_i,ebook_access")}`;
  const json = await getJSON<{ docs: OLDoc[] }>(url);
  return json.docs
    .filter((d) => d.cover_i && d.key && isSafe(d.title))
    .slice(0, 8)
    .map((d) => ({
      id: `ol:${d.key}`,
      title: d.title,
      desc: [d.author_name?.[0], d.first_publish_year].filter(Boolean).join(" · "),
      url: `https://openlibrary.org${d.key}`,
      thumb: `https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`,
      source: "Open Library",
      kind: "book" as const,
      badge: d.ebook_access === "public" ? "Free to read" : "Free to borrow",
    }));
}

export function getBooks(q: string, force = false): Promise<Resource[]> {
  const query = cleanQuery(q);
  return cached(
    `books:${query.toLowerCase()}`,
    12 * HOUR,
    async () => {
      const [ol, wb] = await Promise.allSettled([
        openLibrary(query),
        wikiPages("en.wikibooks.org", query, 5),
      ]);
      const books = ol.status === "fulfilled" ? ol.value : [];
      const wikibooks =
        wb.status === "fulfilled"
          ? wb.value
              .filter((p) => !isDisambig(p))
              .map((p) => toResource(p, "Wikibooks", "book"))
              .filter((r): r is Resource => !!r)
              .map((r) => ({ ...r, badge: "Free textbook" }))
          : [];
      if (ol.status === "rejected" && wb.status === "rejected") throw new Error("books unavailable");
      return [...wikibooks.slice(0, 3), ...books];
    },
    force
  );
}

/* ───────────────────────── Articles (DEV Community) ───────────────────────── */

interface DevArticle {
  id: number;
  title: string;
  description: string;
  url: string;
  cover_image: string | null;
  social_image?: string | null;
  readable_publish_date: string;
  reading_time_minutes: number;
  public_reactions_count: number;
  user: { name: string };
}

function devToResource(a: DevArticle): Resource | null {
  const url = safeUrl(a.url);
  if (!url || !isSafe(a.title, a.description)) return null;
  return {
    id: `dev:${a.id}`,
    title: a.title,
    desc: truncate(a.description, 150),
    url,
    thumb: a.cover_image || a.social_image || undefined,
    source: "DEV Community",
    kind: "article",
    meta: `${a.user.name} · ${a.reading_time_minutes} min read`,
  };
}

export function getArticles(q: string, tag: string | undefined, force = false): Promise<Resource[]> {
  const t = tag || tagSlug(cleanQuery(q));
  if (!t) return Promise.resolve([]);
  return cached(
    `dev:${t}`,
    HOUR,
    async () => {
      let list = await getJSON<DevArticle[]>(`https://dev.to/api/articles?tag=${enc(t)}&per_page=12&top=90`);
      if (list.length < 3) list = await getJSON<DevArticle[]>(`https://dev.to/api/articles?tag=${enc(t)}&per_page=12&top=365`);
      return list.map(devToResource).filter((r): r is Resource => !!r).slice(0, 9);
    },
    force
  );
}

/** Home page "fresh from the web" – top learning posts this week. */
export function getTrending(force = false): Promise<Resource[]> {
  return cached(
    "trending:beginners",
    HOUR,
    async () => {
      const list = await getJSON<DevArticle[]>("https://dev.to/api/articles?tag=beginners&per_page=12&top=7");
      return list.map(devToResource).filter((r): r is Resource => !!r).slice(0, 6);
    },
    force
  );
}

/* ───────────────────────── Videos (live) ───────────────────────── */

interface PipedItem {
  url: string;
  type: string;
  title: string;
  uploaderName: string;
  uploadedDate?: string;
  duration: number;
  views: number;
  isShort?: boolean;
}

// Public Piped API instances (keyless YouTube search with CORS). First that answers wins.
// Add more with VITE_PIPED_INSTANCES="https://a.example,https://b.example" at build time.
const EXTRA_PIPED = ((import.meta.env.VITE_PIPED_INSTANCES as string | undefined) || "")
  .split(",")
  .map((s) => s.trim().replace(/\/+$/, ""))
  .filter((s) => /^https:\/\//.test(s));
const PIPED = ["https://api.piped.private.coffee", ...EXTRA_PIPED];

async function pipedSearch(query: string): Promise<Video[]> {
  const run = (host: string) => async () => {
    const json = await getJSON<{ items: PipedItem[] }>(
      `${host}/search?q=${enc(query)}&filter=videos`,
      7000
    );
    if (!json.items?.length) throw new Error("empty");
    return json.items;
  };
  const items = await firstSuccess(PIPED.map(run), 1800);
  return items
    .filter((i) => i.type === "stream" && !i.isShort && i.duration >= 240 && i.duration <= 10 * 3600)
    .filter((i) => isSafe(i.title, i.uploaderName))
    .map((i) => {
      const id = /[?&]v=([\w-]{11})/.exec(i.url)?.[1];
      return id
        ? ({
            id,
            title: i.title,
            channel: i.uploaderName,
            duration: formatSeconds(i.duration),
            views: compactNumber(i.views),
            published: i.uploadedDate,
            origin: "live",
          } as Video)
        : null;
    })
    .filter((v): v is Video => !!v)
    .slice(0, 12);
}

interface YTApiSearch {
  items: Array<{ id: { videoId: string }; snippet: { title: string; channelTitle: string; publishedAt: string } }>;
}

async function youtubeApiSearch(query: string): Promise<Video[]> {
  const url =
    `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=12&videoEmbeddable=true` +
    `&safeSearch=strict&videoDuration=medium&relevanceLanguage=en&q=${enc(query)}&key=${enc(YT_API_KEY)}`;
  const json = await getJSON<YTApiSearch>(url);
  return json.items
    .filter((i) => i.id?.videoId && isSafe(i.snippet.title, i.snippet.channelTitle))
    .map((i) => ({
      id: i.id.videoId,
      title: stripHtml(i.snippet.title),
      channel: i.snippet.channelTitle,
      published: new Date(i.snippet.publishedAt).getFullYear().toString(),
      origin: "live" as const,
    }));
}

export function getLiveVideos(q: string, force = false): Promise<Video[]> {
  const query = `${cleanQuery(q)} tutorial for beginners`;
  return cached(
    `yt:${query.toLowerCase()}`,
    3 * HOUR,
    async () => {
      if (YT_API_KEY) {
        try {
          const list = await youtubeApiSearch(query);
          if (list.length) return list;
        } catch {
          /* quota exceeded or key restricted – fall through to the keyless route */
        }
      }
      return pipedSearch(query);
    },
    force
  );
}

/* ───────────────────────── Autocomplete ───────────────────────── */

export async function suggestRemote(q: string): Promise<string[]> {
  if (q.trim().length < 2) return [];
  const json = await getJSON<[string, string[]]>(
    `https://en.wikipedia.org/w/api.php?action=opensearch&format=json&origin=*&limit=6&namespace=0&search=${enc(q)}`,
    4500
  );
  return (json[1] || []).filter((s) => isSafe(s));
}

