/**
 * Self-updating site.
 *
 * After the site is live, every visitor's browser quietly checks whether a newer build has been deployed.
 *  - On load (after a short delay), every 10 minutes, and whenever the tab becomes visible again.
 *  - It compares a fingerprint of the running page's scripts/styles with the freshly-fetched index.html
 *    (works for the single-file build AND for normal hashed-asset builds).
 *  - If something changed, a small "new version" banner appears, and the update is applied silently
 *    the next time the visitor searches or navigates. No manual refresh, no stale site.
 */
const CHECK_EVERY = 10 * 60_000;

function hash(str: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(36) + ":" + str.length;
}

function fingerprint(doc: Document): string {
  const parts: string[] = [];
  doc.querySelectorAll("script").forEach((s) => {
    const type = s.getAttribute("type") || "";
    if (type === "application/ld+json") return;
    const src = s.getAttribute("src");
    parts.push(src ? `s:${src}` : `i:${hash(s.textContent || "")}`);
  });
  doc.querySelectorAll('link[rel="stylesheet"]').forEach((l) => {
    const href = l.getAttribute("href") || "";
    if (href.startsWith("http") && !href.startsWith(location.origin)) return; // ignore Google Fonts etc.
    parts.push(`l:${href}`);
  });
  doc.querySelectorAll("style").forEach((s) => parts.push(`y:${hash(s.textContent || "")}`));
  return parts.join("|");
}

let baseline = "";

/** Call once, as early as possible (before the app renders and injects anything). */
export function captureBaseline() {
  try {
    baseline = fingerprint(document);
  } catch {
    baseline = "";
  }
}

async function check(): Promise<boolean> {
  if (!baseline || window.__loUpdateReady) return false;
  try {
    const res = await fetch(location.pathname + "?_v=" + Date.now(), { cache: "no-store", credentials: "same-origin" });
    if (!res.ok) return false;
    const html = await res.text();
    if (!/<div id="root"/.test(html)) return false; // got an error page, not our app
    const doc = new DOMParser().parseFromString(html, "text/html");
    const latest = fingerprint(doc);
    if (latest && latest !== baseline) {
      window.__loUpdateReady = true;
      window.dispatchEvent(new Event("lo:update"));
      return true;
    }
  } catch {
    /* offline – try again later */
  }
  return false;
}

export function startUpdater() {
  if (import.meta.env.DEV) return;
  let last = Date.now();
  const run = async () => {
    last = Date.now();
    await check();
    navigator.serviceWorker?.getRegistration().then((r) => r?.update()).catch(() => undefined);
  };
  setTimeout(run, 20_000);
  setInterval(run, CHECK_EVERY);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && Date.now() - last > 3 * 60_000) void run();
  });
}

export function registerServiceWorker() {
  if (import.meta.env.DEV || !("serviceWorker" in navigator)) return;
  const secure = location.protocol === "https:" || location.hostname === "localhost";
  if (!secure) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(import.meta.env.BASE_URL + "sw.js").catch(() => undefined);
  });
}
