export async function getJSON<T>(url: string, timeout = 9000): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

/** Resolves with the first promise that succeeds (Promise.any polyfill for ES2020 targets). */
export function firstSuccess<T>(tasks: Array<() => Promise<T>>, staggerMs = 0): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let failed = 0;
    let settled = false;
    const errors: unknown[] = [];
    tasks.forEach((task, i) => {
      setTimeout(() => {
        if (settled) return;
        task()
          .then((v) => {
            if (!settled) {
              settled = true;
              resolve(v);
            }
          })
          .catch((e) => {
            errors.push(e);
            failed++;
            if (failed === tasks.length && !settled) reject(errors[0]);
          });
      }, i * staggerMs);
    });
  });
}
