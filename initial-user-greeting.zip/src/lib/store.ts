import { useSyncExternalStore } from "react";
import type { SavedItem } from "./types";

/** Minimal localStorage-backed external store (works across tabs, never throws). */
function createStore<T>(key: string, initial: T) {
  const listeners = new Set<() => void>();
  const read = (): T => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  };
  let value = read();
  if (typeof window !== "undefined") {
    window.addEventListener("storage", (e) => {
      if (e.key === key) {
        value = read();
        listeners.forEach((l) => l());
      }
    });
  }
  return {
    get: () => value,
    set(next: T) {
      value = next;
      try {
        localStorage.setItem(key, JSON.stringify(next));
      } catch {
        /* private mode / quota – state still lives in memory */
      }
      listeners.forEach((l) => l());
    },
    subscribe(l: () => void) {
      listeners.add(l);
      return () => listeners.delete(l);
    },
  };
}

type Store<T> = ReturnType<typeof createStore<T>>;
const useStore = <T,>(s: Store<T>): T => useSyncExternalStore(s.subscribe, s.get, s.get);

/* Saved items ("My learning list") */
const savedStore = createStore<SavedItem[]>("lo:saved", []);
export const useSaved = () => useStore(savedStore);
export function toggleSaved(item: Omit<SavedItem, "savedAt">): boolean {
  const list = savedStore.get();
  const exists = list.some((i) => i.id === item.id);
  savedStore.set(exists ? list.filter((i) => i.id !== item.id) : [{ ...item, savedAt: Date.now() }, ...list]);
  return !exists;
}
export const removeSaved = (id: string) => savedStore.set(savedStore.get().filter((i) => i.id !== id));
export const clearSaved = () => savedStore.set([]);

/* Roadmap progress per topic */
const progressStore = createStore<Record<string, number[]>>("lo:progress", {});
export const useProgress = () => useStore(progressStore);
export function toggleStep(topic: string, step: number) {
  const all = progressStore.get();
  const key = topic.toLowerCase();
  const cur = all[key] || [];
  progressStore.set({ ...all, [key]: cur.includes(step) ? cur.filter((s) => s !== step) : [...cur, step] });
}

/* Recent searches */
const recentStore = createStore<string[]>("lo:recent", []);
export const useRecent = () => useStore(recentStore);
export function addRecent(q: string) {
  const clean = q.trim();
  if (!clean) return;
  recentStore.set([clean, ...recentStore.get().filter((r) => r.toLowerCase() !== clean.toLowerCase())].slice(0, 8));
}
export const clearRecent = () => recentStore.set([]);

/* Theme */
export type Theme = "dark" | "light";
const themeStore = createStore<Theme>("lo:theme", "dark");
export const useTheme = () => useStore(themeStore);
export function applyTheme(t: Theme = themeStore.get()) {
  document.documentElement.classList.toggle("light", t === "light");
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t === "light" ? "#f6f6fc" : "#070711");
}
export function toggleTheme() {
  const next: Theme = themeStore.get() === "dark" ? "light" : "dark";
  themeStore.set(next);
  applyTheme(next);
}
