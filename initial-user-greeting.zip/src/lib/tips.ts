export interface Tip {
  icon: string;
  title: string;
  body: string;
}

export interface PlanWeek {
  week: string;
  focus: string;
  tasks: string[];
}

const BY_CATEGORY: Record<string, Tip[]> = {
  tech: [
    { icon: "⌨️", title: "Type along, don't just watch", body: "Pause the video and write the code yourself. Watching feels like learning; typing is learning." },
    { icon: "🧱", title: "Ship tiny projects", body: "A calculator, a to-do list or a small scraper teaches more than an unfinished giant project." },
    { icon: "🐞", title: "Treat errors as instructions", body: "Read the first line of an error out loud, then search the exact message. Debugging is the real skill." },
    { icon: "🌿", title: "Use Git from day one", body: "Put every practice project on GitHub. In a few months it becomes your portfolio." },
    { icon: "🔍", title: "Search like a developer", body: "Include the language or framework, the exact error text and the year. Prefer official docs first." },
    { icon: "🦆", title: "Explain it to a rubber duck", body: "If you can't explain your code line by line, you haven't understood it yet." },
  ],
  creative: [
    { icon: "🎯", title: "Copy to learn", body: "Recreate work you admire, just for practice. You'll notice choices you'd never spot by looking." },
    { icon: "📆", title: "Make something small daily", body: "One tiny finished piece a day builds skill faster than one perfect piece a month." },
    { icon: "🧰", title: "Limit your tools", body: "Stay with one tool until it feels natural. Switching apps resets your progress." },
    { icon: "💬", title: "Ask for feedback early", body: "Share work-in-progress in a friendly community. Critique is a shortcut." },
    { icon: "🖼️", title: "Build a reference board", body: "Collect examples you love and note what makes them work: colour, spacing, light, rhythm." },
    { icon: "📐", title: "Master the fundamentals", body: "Composition, contrast and colour apply to every tool. Learn them once, use them forever." },
  ],
  music: [
    { icon: "⏱️", title: "Short and daily beats long and rare", body: "15–20 focused minutes every day beats a 2-hour session once a week." },
    { icon: "🐢", title: "Slow is fast", body: "Use a metronome and play slowly until it's clean. Speed arrives on its own." },
    { icon: "🎶", title: "Learn songs you love", body: "Motivation matters. Pick simple versions of music you genuinely enjoy." },
    { icon: "🎙️", title: "Record yourself", body: "Playback shows mistakes you can't hear while playing. Compare week to week." },
    { icon: "🔥", title: "Always warm up", body: "Five minutes of gentle exercises protects your hands and voice and sharpens accuracy." },
    { icon: "👂", title: "Train your ear", body: "Try figuring out a melody by ear before looking up the notes." },
  ],
  languages: [
    { icon: "🗣️", title: "Speak from day one", body: "Say phrases out loud, even to yourself. Speaking is a muscle, and it needs reps." },
    { icon: "💬", title: "Learn phrases, not lone words", body: "Chunks like “Could I have…?” are faster to learn and sound more natural." },
    { icon: "🎧", title: "Get comprehensible input", body: "Watch shows and listen to podcasts at your level, with subtitles in the target language." },
    { icon: "🃏", title: "Use spaced-repetition flashcards", body: "Short daily reviews lock vocabulary into long-term memory." },
    { icon: "🤝", title: "Find a conversation partner", body: "Language-exchange apps and local meetups give you real practice and instant feedback." },
    { icon: "📱", title: "Switch your phone's language", body: "Free daily immersion — you'll pick up everyday words without extra effort." },
  ],
  business: [
    { icon: "🧪", title: "Run small experiments", body: "Test an idea cheaply before investing weeks. Learn from real feedback, not assumptions." },
    { icon: "📊", title: "Track the numbers", body: "Keep a simple spreadsheet of what you tried and what happened." },
    { icon: "📚", title: "Study real case studies", body: "Read how real companies and people succeeded and failed, then note the patterns." },
    { icon: "🗣️", title: "Talk to real people", body: "Interview customers, mentors or peers. Ten honest conversations beat a month of guessing." },
    { icon: "🛡️", title: "Protect your downside", body: "Never risk money you can't afford to lose. This is educational content, not financial advice." },
    { icon: "🚩", title: "Be wary of “get rich quick”", body: "If it promises guaranteed returns or needs you to recruit others, walk away." },
  ],
  health: [
    { icon: "🔁", title: "Consistency beats intensity", body: "Three easy sessions a week for a year beats one brutal month followed by quitting." },
    { icon: "🌱", title: "Start easier than you think", body: "Finish every session feeling like you could do a little more. Build up gradually." },
    { icon: "🪞", title: "Form first, then load", body: "Learn the movement slowly and correctly before adding speed, weight or time." },
    { icon: "😴", title: "Rest is part of training", body: "Sleep, water and rest days are when your body adapts. Listen to it." },
    { icon: "✅", title: "Track your habit", body: "Tick off each day on a calendar. A visible streak is surprisingly motivating." },
    { icon: "🩺", title: "Check with a professional", body: "If you have a medical condition or pain, ask a doctor first. This is general information only." },
  ],
  life: [
    { icon: "📖", title: "Follow one guide fully first", body: "Do it by the book once before improvising. You'll know what you're changing and why." },
    { icon: "🔁", title: "Repeat the basics", body: "Fundamentals — knife skills, opening principles, sentence structure — power everything else." },
    { icon: "⛓️", title: "Stack it onto a habit", body: "Attach practice to something you already do, like “after coffee, 15 minutes of practice”." },
    { icon: "📓", title: "Keep a simple log", body: "Write what you tried and what you'd change. Notes turn experience into skill." },
    { icon: "🧑‍🏫", title: "Learn from experts' mistakes", body: "Search for “common mistakes” — it's the cheapest shortcut available." },
    { icon: "🤲", title: "Teach someone", body: "Explaining what you learned to a friend exposes gaps and cements the knowledge." },
  ],
  science: [
    { icon: "✍️", title: "Solve problems, don't just watch", body: "Pause, try the problem yourself, then compare. Struggling a bit is where learning happens." },
    { icon: "💡", title: "Understand the “why” first", body: "Formulas make sense once you see where they come from. Ask “why does this work?”" },
    { icon: "🎨", title: "Draw it out", body: "Diagrams, graphs and sketches turn abstract ideas into something you can reason about." },
    { icon: "🧠", title: "Use the Feynman technique", body: "Explain the idea in plain words as if to a child. Gaps in your explanation are gaps in your understanding." },
    { icon: "🌍", title: "Connect it to real life", body: "Find where the concept shows up around you. It makes it stick." },
    { icon: "❌", title: "Learn from wrong answers", body: "Keep a mistakes notebook and revisit it before exams. It's the highest-value page you'll write." },
  ],
};

const GENERAL: Array<(t: string) => Tip> = [
  (t) => ({ icon: "🎯", title: "Start with a tiny daily goal", body: `Commit to just 20 minutes of ${t} a day. Small and daily beats long and rare — and it's easier to start.` }),
  (t) => ({ icon: "🧠", title: "Test yourself (active recall)", body: `After each session, close the tab and write down everything you remember about ${t}. Retrieval builds memory.` }),
  () => ({ icon: "📅", title: "Space your reviews", body: "Revisit what you learned after 1 day, 3 days, 1 week and 3 weeks. Spaced repetition beats cramming." }),
  (t) => ({ icon: "🧑‍🏫", title: "Teach it back", body: `Explain a ${t} concept to a friend (or a notebook) in simple words. If you get stuck, that's what to study next.` }),
  (t) => ({ icon: "🛠️", title: "Learn by making something", body: `Pick a mini project for ${t} in week one. Applying skills beats collecting tutorials.` }),
  () => ({ icon: "1️⃣", title: "One main resource at a time", body: "Resource-hopping feels productive but stalls progress. Finish one course or book before starting another." }),
  () => ({ icon: "⏲️", title: "Use 25/5 focus sprints", body: "Work 25 focused minutes, rest 5. Phone away, one tab open." }),
  () => ({ icon: "😴", title: "Protect your sleep", body: "Sleep is when your brain consolidates new skills. An early night often beats an extra hour of practice." }),
  (t) => ({ icon: "👥", title: "Join a community", body: `Find a friendly ${t} community. Questions, feedback and accountability keep you going.` }),
  () => ({ icon: "📈", title: "Make progress visible", body: "Keep a checklist, journal or streak. Seeing how far you've come is the best motivation on hard days." }),
];

export const MISTAKES: string[] = [
  "Collecting resources instead of starting. Pick one and begin today.",
  "Only watching or reading. Always pair input with practice.",
  "Skipping the basics to reach the “cool stuff”. Foundations make everything easier later.",
  "Comparing your day 5 to someone's year 5. Compare yourself with last week's you.",
  "Quitting during the plateau. Plateaus are normal — they usually mean a jump is coming.",
];

export function getTips(topic: string, catId?: string): { specific: Tip[]; general: Tip[] } {
  return {
    specific: catId ? BY_CATEGORY[catId] || [] : [],
    general: GENERAL.map((fn) => fn(topic)),
  };
}

export function buildPlan(topic: string): PlanWeek[] {
  return [
    {
      week: "Week 1",
      focus: "Foundations",
      tasks: [`Get the big picture of ${topic} and learn its key terms`, "Watch one beginner crash course start to finish", "Practice 20 minutes a day, even if it's messy"],
    },
    {
      week: "Week 2",
      focus: "Practice",
      tasks: [`Repeat the core ${topic} basics until they feel easy`, "Follow a structured free course or book chapter", "Write down 5 things you still find confusing"],
    },
    {
      week: "Week 3",
      focus: "Build something",
      tasks: [`Pick a small ${topic} project you actually care about`, "Get stuck, search, fix it — that's the learning", "Ask one question in a beginner community"],
    },
    {
      week: "Week 4",
      focus: "Share & level up",
      tasks: ["Show your project to a friend or online and ask for feedback", "Review your notes and fill the gaps", "Choose your next challenge and set a new 4-week goal"],
    },
  ];
}
