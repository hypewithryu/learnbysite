import { useEffect, useState } from "react";

export interface SourceState<T> {
  status: "loading" | "ok" | "error";
  data: T | undefined;
}

/**
 * Runs an async loader for `key`, exposes loading / ok / error + data.
 * Bumping `nonce` forces a refresh (the loader receives force = true) while keeping old data on screen.
 */
export function useSource<T>(key: string, load: (force: boolean) => Promise<T>, nonce = 0): SourceState<T> {
  const [state, setState] = useState<SourceState<T> & { key: string }>({ status: "loading", data: undefined, key });

  useEffect(() => {
    let alive = true;
    setState((s) => ({ status: "loading", data: s.key === key ? s.data : undefined, key }));
    load(nonce > 0)
      .then((data) => alive && setState({ status: "ok", data, key }))
      .catch(() => alive && setState((s) => ({ status: "error", data: s.key === key ? s.data : undefined, key })));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, nonce]);

  // while the key changed but the effect hasn't run yet, report loading
  if (state.key !== key) return { status: "loading", data: undefined };
  return { status: state.status, data: state.data };
}
