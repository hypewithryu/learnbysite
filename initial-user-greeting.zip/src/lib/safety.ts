/**
 * Link guard — keeps pirated / "cracked" / spammy material out of the results.
 * Everything that comes back from a live API passes through isSafe() before it is shown.
 */
const BAD =
  /\b(keygen|key ?gen|warez|nulled|pirated|torrents?|serial keys?|license keys?|product keys?|activators?|mod apk|apk mod|free download full)\b|\bcrack(?:ed|s)?\b[^.]{0,30}\b(download|software|full version|serial|key|patch|activation|free|keygen)\b|\b(download|full version|free)\b[^.]{0,30}\bcrack(?:ed|s)?\b|\bcracked\b/i;

const QUERY_BAD =
  /\b(keygen|warez|nulled|pirated|torrents?|serial keys?|activators?|mod apk)\b|\bcrack(?:ed)?\b(?!.*\b(interview|exam|code|coding|case|egg|password)\b)/i;

export function isSafe(...parts: Array<string | undefined>): boolean {
  return !BAD.test(parts.filter(Boolean).join(" "));
}

export function hasPiracyIntent(q: string): boolean {
  return QUERY_BAD.test(q);
}

export function stripPiracyWords(q: string): string {
  return q
    .replace(/\b(keygen|warez|nulled|pirated|torrents?|serial keys?|activators?|mod apk|crack(?:ed)?|free download|full version|download)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Only ever allow http(s) URLs through to href attributes. */
export function safeUrl(url: string | undefined): string | undefined {
  if (!url) return undefined;
  try {
    const u = new URL(url, "https://example.com");
    return u.protocol === "https:" || u.protocol === "http:" ? url : undefined;
  } catch {
    return undefined;
  }
}
