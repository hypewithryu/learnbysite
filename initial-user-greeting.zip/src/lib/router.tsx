import { useMemo, useSyncExternalStore, type AnchorHTMLAttributes, type MouseEvent, type ReactNode } from "react";
import type { Route, Tab } from "./types";

/**
 * Query-string routing (/?q=guitar&tab=videos).
 * It works on EVERY static host with zero server config (no rewrite rules needed),
 * and search engines can crawl and index each /?q=… URL.
 */
const TABS: Tab[] = ["all", "videos", "read", "learn", "tips", "links"];

export function parseRoute(search: string): Route {
  const p = new URLSearchParams(search);
  const q = (p.get("q") || "").trim().slice(0, 120);
  if (q) {
    const tab = p.get("tab") as Tab;
    return { name: "search", q, tab: TABS.includes(tab) ? tab : "all" };
  }
  const cat = p.get("cat");
  if (cat) return { name: "category", id: cat };
  return { name: "home" };
}

export function hrefFor(route: Route): string {
  const base = typeof location !== "undefined" ? location.pathname : "/";
  if (route.name === "search") {
    const p = new URLSearchParams({ q: route.q });
    if (route.tab !== "all") p.set("tab", route.tab);
    return `${base}?${p.toString()}`;
  }
  if (route.name === "category") return `${base}?cat=${encodeURIComponent(route.id)}`;
  return base;
}

declare global {
  interface Window {
    __loUpdateReady?: boolean;
  }
}

export function navigate(to: Route | string, opts: { replace?: boolean; scroll?: boolean } = {}) {
  const href = typeof to === "string" ? to : hrefFor(to);
  // A new version of the site is waiting – apply it silently on this navigation.
  if (window.__loUpdateReady) {
    window.location.assign(href);
    return;
  }
  if (opts.replace) history.replaceState({}, "", href);
  else history.pushState({}, "", href);
  window.dispatchEvent(new Event("lo:nav"));
  if (opts.scroll !== false) window.scrollTo({ top: 0, behavior: "auto" });
}

const subscribe = (cb: () => void) => {
  window.addEventListener("popstate", cb);
  window.addEventListener("lo:nav", cb);
  return () => {
    window.removeEventListener("popstate", cb);
    window.removeEventListener("lo:nav", cb);
  };
};

export function useRoute(): Route {
  const search = useSyncExternalStore(subscribe, () => location.search, () => "");
  return useMemo(() => parseRoute(search), [search]);
}

interface LinkProps extends Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> {
  to: Route;
  scroll?: boolean;
  children: ReactNode;
}

/** Real <a href> (so crawlers can follow it) with instant client-side navigation. */
export function Link({ to, scroll, children, onClick, ...rest }: LinkProps) {
  const href = hrefFor(to);
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    navigate(to, { scroll });
  };
  return (
    <a href={href} onClick={handle} {...rest}>
      {children}
    </a>
  );
}

export const searchRoute = (q: string, tab: Tab = "all"): Route => ({ name: "search", q, tab });
