const FILLER =
  /\b(how to|how do i|how can i|how do you|learning|learn|studying|study|master|teach me|tutorials?|courses?|lessons?|classes?|training|for beginners?|beginner'?s?|basics?|guide|free|online|from scratch|step by step|best way to|i want to|want to|to learn|please|full)\b/gi;

/** Strip filler words ("how to learn guitar for beginners" -> "guitar"). */
export function cleanQuery(raw: string): string {
  const base = raw.replace(/[^\p{L}\p{N}\s+#&./'-]/gu, " ").replace(/\s+/g, " ").trim();
  const stripped = base.replace(FILLER, " ").replace(/\s+/g, " ").trim();
  return stripped || base;
}

/** Lowercase + remove punctuation so "HTML & CSS" ~ "html css". */
export function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/&/g, " ")
    .replace(/[^\p{L}\p{N}+#\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function titleCase(s: string): string {
  return s
    .split(" ")
    .map((w) => (w ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(" ");
}

export function tagSlug(s: string): string {
  return s.toLowerCase().replace(/c\+\+/g, "cpp").replace(/c#/g, "csharp").replace(/[^a-z0-9]/g, "");
}

export function truncate(s: string | undefined, n: number): string {
  if (!s) return "";
  const t = s.replace(/\s+/g, " ").trim();
  return t.length <= n ? t : t.slice(0, n - 1).replace(/[\s,.;:-]+\S*$/, "") + "…";
}

export function compactNumber(n: number): string {
  if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, "") + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1e3) return Math.round(n / 1e3) + "K";
  return String(n);
}

export function formatSeconds(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const mm = h ? String(m).padStart(2, "0") : String(m);
  return (h ? h + ":" : "") + mm + ":" + String(s).padStart(2, "0");
}

export function timeAgo(ts: number): string {
  const diff = Math.max(0, Date.now() - ts);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hr ago`;
  return `${Math.floor(h / 24)} d ago`;
}

export function stripHtml(s: string): string {
  return s.replace(/<[^>]*>/g, "").replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&#039;/g, "'");
}

export function ytThumb(id: string, q: "mq" | "hq" | "maxres" = "hq"): string {
  return `https://i.ytimg.com/vi/${id}/${q}default.jpg`;
}

export function ytWatch(id: string): string {
  return `https://www.youtube.com/watch?v=${id}`;
}
