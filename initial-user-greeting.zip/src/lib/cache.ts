/**
 * Tiny stale-while-revalidate cache backed by localStorage (with in-memory fallback).
 * - Fresh entries are served instantly (no network).
 * - Expired entries trigger a refetch; if the network fails we fall back to the stale copy,
 *   so the site keeps working even when a source is temporarily down.
 */
const PREFIX = "lo:v2:";
const mem = new Map<string, { ts: number; data: unknown }>();

interface Entry<T> {
  ts: number;
  data: T;
}

function read<T>(key: string): Entry<T> | null {
  const m = mem.get(key) as Entry<T> | undefined;
  if (m) return m;
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Entry<T>;
    mem.set(key, parsed);
    return parsed;
  } catch {
    return null;
  }
}

function write<T>(key: string, data: T) {
  const entry = { ts: Date.now(), data };
  mem.set(key, entry);
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(entry));
  } catch {
    // quota exceeded: drop old cache entries and try once more
    try {
      Object.keys(localStorage)
        .filter((k) => k.startsWith(PREFIX))
        .forEach((k) => localStorage.removeItem(k));
      localStorage.setItem(PREFIX + key, JSON.stringify(entry));
    } catch {
      /* storage unavailable – memory cache still works */
    }
  }
}

export function cacheAge(key: string): number | null {
  const e = read(key);
  return e ? e.ts : null;
}

export async function cached<T>(
  key: string,
  ttlMs: number,
  fetcher: () => Promise<T>,
  force = false
): Promise<T> {
  const hit = read<T>(key);
  if (hit && !force && Date.now() - hit.ts < ttlMs) return hit.data;
  try {
    const data = await fetcher();
    write(key, data);
    return data;
  } catch (err) {
    if (hit) return hit.data; // serve stale rather than fail
    throw err;
  }
}

export const MIN = 60_000;
export const HOUR = 60 * MIN;
