import { useEffect } from "react";
import { absUrl, SITE } from "./config";

function setMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

function setJsonLd(items: object[]) {
  document.head.querySelectorAll("script[data-lo-jsonld]").forEach((n) => n.remove());
  items.forEach((item) => {
    const s = document.createElement("script");
    s.type = "application/ld+json";
    s.setAttribute("data-lo-jsonld", "1");
    s.textContent = JSON.stringify(item);
    document.head.appendChild(s);
  });
}

export interface SEOInput {
  title: string;
  description: string;
  /** query string for the canonical URL, e.g. "?q=guitar" */
  search?: string;
  image?: string;
  noindex?: boolean;
  jsonLd?: object[];
}

/** Keeps <title>, meta description, canonical, Open Graph, Twitter cards and JSON-LD in sync with the page. */
export function useSEO({ title, description, search = "", image, noindex, jsonLd = [] }: SEOInput) {
  const ld = JSON.stringify(jsonLd);
  useEffect(() => {
    const url = absUrl(search);
    const img = image || absUrl("og-image.png");
    const desc = description.slice(0, 300);
    document.title = title;
    setMeta("name", "description", desc);
    setMeta("name", "robots", noindex ? "noindex, follow" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");
    setLink("canonical", url);
    setMeta("property", "og:title", title);
    setMeta("property", "og:description", desc);
    setMeta("property", "og:url", url);
    setMeta("property", "og:image", img);
    setMeta("property", "og:site_name", SITE.name);
    setMeta("name", "twitter:card", "summary_large_image");
    setMeta("name", "twitter:title", title);
    setMeta("name", "twitter:description", desc);
    setMeta("name", "twitter:image", img);
    setJsonLd(JSON.parse(ld) as object[]);
  }, [title, description, search, image, noindex, ld]);
}
