/**
 * Direct-link directory.
 * Every URL here is a *search or landing URL on a major platform* built from the visitor's query.
 * They don't point at individual pages that can disappear, so they can't go stale or 404.
 */
export type Price = "free" | "freemium" | "paid";
export type PlatformKind = "Videos" | "Courses" | "Articles" | "Books" | "Community" | "Practice";

export interface Platform {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  price: Price;
  kind: PlatformKind;
  /** limit to categories (omit = all) */
  cats?: string[];
  url: (q: string) => string;
}

const e = encodeURIComponent;

export const PLATFORMS: Platform[] = [
  { id: "youtube", name: "YouTube", emoji: "▶️", desc: "Millions of free tutorials and full courses", price: "free", kind: "Videos", url: (q) => `https://www.youtube.com/results?search_query=${e(q + " tutorial for beginners")}` },
  { id: "khan", name: "Khan Academy", emoji: "🎓", desc: "Free world-class lessons and practice", price: "free", kind: "Courses", cats: ["science", "business", "life", "tech"], url: (q) => `https://www.khanacademy.org/search?page_search_query=${e(q)}` },
  { id: "ocw", name: "MIT OpenCourseWare", emoji: "🏛️", desc: "Free university course materials from MIT", price: "free", kind: "Courses", cats: ["tech", "science", "business"], url: (q) => `https://ocw.mit.edu/search/?q=${e(q)}` },
  { id: "classcentral", name: "Class Central", emoji: "🧭", desc: "Find free courses from top universities", price: "free", kind: "Courses", url: (q) => `https://www.classcentral.com/search?q=${e(q)}` },
  { id: "coursera", name: "Coursera", emoji: "📘", desc: "University courses — many can be audited free", price: "freemium", kind: "Courses", url: (q) => `https://www.coursera.org/search?query=${e(q)}` },
  { id: "edx", name: "edX", emoji: "🎒", desc: "Courses from Harvard, MIT and more", price: "freemium", kind: "Courses", url: (q) => `https://www.edx.org/search?q=${e(q)}` },
  { id: "fcc", name: "freeCodeCamp", emoji: "🔥", desc: "Free coding tutorials and certifications", price: "free", kind: "Articles", cats: ["tech"], url: (q) => `https://www.freecodecamp.org/news/search/?query=${e(q)}` },
  { id: "mdn", name: "MDN Web Docs", emoji: "📚", desc: "The reference for web technologies", price: "free", kind: "Articles", cats: ["tech"], url: (q) => `https://developer.mozilla.org/en-US/search?q=${e(q)}` },
  { id: "github", name: "GitHub", emoji: "🐙", desc: "Open-source projects and learning repos", price: "free", kind: "Practice", cats: ["tech"], url: (q) => `https://github.com/search?q=${e(q)}&type=repositories` },
  { id: "stackoverflow", name: "Stack Overflow", emoji: "🧩", desc: "Answers to real questions from real people", price: "free", kind: "Community", cats: ["tech"], url: (q) => `https://stackoverflow.com/search?q=${e(q)}` },
  { id: "devto", name: "DEV Community", emoji: "👩‍💻", desc: "Developer articles and discussions", price: "free", kind: "Articles", cats: ["tech"], url: (q) => `https://dev.to/search?q=${e(q)}` },
  { id: "codecademy", name: "Codecademy", emoji: "💻", desc: "Interactive coding lessons", price: "freemium", kind: "Practice", cats: ["tech"], url: (q) => `https://www.codecademy.com/search?query=${e(q)}` },
  { id: "wikipedia", name: "Wikipedia", emoji: "🌐", desc: "Free encyclopedia — great for the big picture", price: "free", kind: "Articles", url: (q) => `https://en.wikipedia.org/w/index.php?search=${e(q)}` },
  { id: "wikibooks", name: "Wikibooks", emoji: "📖", desc: "Free open-content textbooks", price: "free", kind: "Books", url: (q) => `https://en.wikibooks.org/w/index.php?search=${e(q)}` },
  { id: "wikiversity", name: "Wikiversity", emoji: "🏫", desc: "Free learning projects and courses", price: "free", kind: "Courses", url: (q) => `https://en.wikiversity.org/w/index.php?search=${e(q)}` },
  { id: "openlibrary", name: "Open Library", emoji: "📕", desc: "Borrow millions of books for free", price: "free", kind: "Books", url: (q) => `https://openlibrary.org/search?q=${e(q)}` },
  { id: "archive", name: "Internet Archive", emoji: "🗄️", desc: "Free lectures, books and documentaries", price: "free", kind: "Books", url: (q) => `https://archive.org/search?query=${e(q)}` },
  { id: "ted", name: "TED", emoji: "🎤", desc: "Inspiring talks from experts", price: "free", kind: "Videos", cats: ["business", "science", "life", "health", "creative"], url: (q) => `https://www.ted.com/search?q=${e(q)}` },
  { id: "reddit", name: "Reddit", emoji: "👽", desc: "Communities, advice and beginner threads", price: "free", kind: "Community", url: (q) => `https://www.reddit.com/search/?q=${e(q + " beginner")}` },
  { id: "medium", name: "Medium", emoji: "✍️", desc: "Articles and personal learning stories", price: "freemium", kind: "Articles", url: (q) => `https://medium.com/search?q=${e(q)}` },
  { id: "udemy", name: "Udemy", emoji: "🛒", desc: "Huge catalog of paid video courses (often on sale)", price: "paid", kind: "Courses", url: (q) => `https://www.udemy.com/courses/search/?q=${e(q)}` },
  { id: "skillshare", name: "Skillshare", emoji: "🎨", desc: "Creative classes taught by practitioners", price: "freemium", kind: "Courses", cats: ["creative", "business", "life", "music"], url: (q) => `https://www.skillshare.com/en/search?query=${e(q)}` },
  { id: "duolingo", name: "Duolingo", emoji: "🦉", desc: "Bite-sized free language practice", price: "free", kind: "Practice", cats: ["languages"], url: () => `https://www.duolingo.com/` },
  { id: "musictheory", name: "musictheory.net", emoji: "🎼", desc: "Free lessons and ear-training exercises", price: "free", kind: "Practice", cats: ["music"], url: () => `https://www.musictheory.net/` },
  { id: "lichess", name: "Lichess", emoji: "♞", desc: "Free chess lessons, puzzles and games", price: "free", kind: "Practice", cats: ["life"], url: () => `https://lichess.org/learn` },
];

export function platformsFor(q: string, catId?: string) {
  return PLATFORMS.filter((p) => !p.cats || !catId || p.cats.includes(catId)).map((p) => ({ ...p, href: p.url(q) }));
}

/** Platform deep-link used by empty states so the visitor is never at a dead end. */
export function youtubeSearchUrl(q: string): string {
  return PLATFORMS[0].url(q);
}
